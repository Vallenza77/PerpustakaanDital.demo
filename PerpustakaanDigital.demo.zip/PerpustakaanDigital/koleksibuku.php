<?php
session_start();

// Memeriksa apakah pengguna sudah login
if (!isset($_SESSION['UserID'])) {
    echo "Silakan login terlebih dahulu.";
    exit();
}

// Include koneksi ke database
include('koneksi.php');

// Mengambil UserID dari session
$UserID = $_SESSION['UserID'];

// Query untuk mengambil data buku yang sudah disimpan di koleksi pribadi
$query = "SELECT koleksipribadi.KoleksID, buku.BukuID, buku.Judul, buku.Penulis, buku.TahunTerbit, buku.foto
          FROM koleksipribadi
          JOIN buku ON koleksipribadi.BukuID = buku.BukuID
          WHERE koleksipribadi.UserID = ?";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $UserID);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Koleksi Buku Pribadi</title>

    <!-- Link ke file CSS Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
         /* Modal Styling */
         .modal-content {
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .modal-header {
            background-color: #007bff;
            color: #fff;
            padding: 15px 20px;
            border-bottom: none;
        }

        .modal-body {
            padding: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            align-items: flex-start;
        }

        .modal-body img {
            width: 100%;
            max-width: 300px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .modal-body .BukuID-details {
            flex: 1;
            padding: 0 20px;
        }

        .modal-body .form-section {
            flex: 1;
        }

        .modal-footer {
            justify-content: space-between;
            padding: 15px 20px;
            background-color: #f9f9f9;
        }

        /* Button Styling */
        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: bold;
        }

        .btn-success:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }
        .action-button {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .deleteButton {
            background-color: #dc3545;
            color: white;
        }
        .deleteButton:hover {
            background-color: #c82333;
        }
        .openButton {
            background-color: #28a745;
            color: white;
        }
        .openButton:hover {
            background-color: #218838;
        }
        .BukuID-foto {
            height: 250px;
            object-fit: cover;
            border-radius: 10px 10px 0 0;
        }
        .card-title {
            font-size: 1.2rem;
            font-weight: bold;
        }
        .card-text {
            color: #555;
        }
        
    </style>
</head>
<body>

<div class="container">
    <h2 class="text-center mb-4">📚 Koleksi Buku Pribadi Anda 📚</h2>

    <?php
    if ($result->num_rows > 0) {
        echo "<div class='row g-4'>"; // Menggunakan grid system dengan gap lebih baik
        while ($row = $result->fetch_assoc()) {
            echo "<div class='col-md-4 col-sm-6'>";
            echo "<div class='card shadow-sm'>";
            echo "<img src='" . $row['foto'] . "' class='card-img-top BukuID-foto' alt='" . $row['Judul'] . "'>";
            echo "<div class='card-body'>";
            echo "<h5 class='card-title'>" . $row['Judul'] . "</h5>";
            echo "<p class='card-text'><strong>Penulis:</strong> " . $row['Penulis'] . "</p>";
            echo "<p class='card-text'><strong>Tahun Terbit:</strong> " . $row['TahunTerbit'] . "</p>";
            echo "<button class='action-button openButton' data-bukuid='" . $row['BukuID'] . "'>📖 Buka Buku</button>";
            echo "<button class='action-button deleteButton' data-koleksid='" . $row['KoleksID'] . "'>🗑 Hapus</button>";
            echo "</div>";
            echo "</div>";
            echo "</div>";
        }
        echo "</div>";
    } else {
        echo "<p class='text-center text-muted'>Anda belum memiliki koleksi buku pribadi.</p>";
    }

    $stmt->close();
    $conn->close();
    ?>
</div>

<!-- Modal Konfirmasi Hapus -->
<div class="modal fade" id="confirmDeleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Konfirmasi Hapus Buku</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Apakah Anda yakin ingin menghapus buku ini dari koleksi Anda?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteButton">Hapus</button>
            </div>
        </div>
    </div>
</div>

<!-- Skrip JavaScript -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
   $(document).ready(function() {
    var KoleksIDToDelete;
    var cardToDelete; 

    // Menyimpan ID koleksi yang ingin dihapus
    $('.deleteButton').click(function() {
        KoleksIDToDelete = $(this).data('koleksid');
        cardToDelete = $(this).closest('.col-md-4'); // Menyimpan elemen card
        $('#confirmDeleteModal').modal('show');
    });

    // Konfirmasi penghapusan
    $('#confirmDeleteButton').click(function() {
        $.ajax({
            url: 'hapuskoleksi.php', // Pastikan nama file sesuai
            type: 'POST',
            data: { deleteKoleksiID: KoleksIDToDelete },
            success: function(response) {
                console.log("Respon server:", response);

                if (response.trim() === "Buku berhasil dihapus dari koleksi.") {
                    $('#confirmDeleteModal').modal('hide'); // Tutup modal
                    cardToDelete.fadeOut(500, function() { $(this).remove(); }); // Hapus elemen dari tampilan
                } else {
                    alert("Gagal menghapus buku. Silakan coba lagi.");
                }
            },
            error: function(xhr, status, error) {
                console.error("Error:", xhr.responseText);
                alert('Terjadi kesalahan, coba lagi nanti!');
            }
        });
    });

        // Fungsi untuk membuka buku
        $('.openButton').click(function() {
            var BukuID = $(this).data('bukuid');
            window.location.href = 'peminjamanuser.php?BukuID=' + BukuID;
        });

        // Membuka profil pengguna saat diklik
        $('#openProfileLink').click(function(event) {
            event.preventDefault();
            if (confirm('Apakah Anda ingin melihat profil Anda?')) {
                window.location.href = 'profiluser.php';
            }
        });
    });
</script>

</body>
</html>
