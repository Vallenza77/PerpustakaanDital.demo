<?php
include('koneksi.php');

$kategori = isset($_POST['kategori']) ? $_POST['kategori'] : 'Semua';
$tahunTerbit = isset($_POST['tahunTerbit']) ? $_POST['tahunTerbit'] : 'Semua';

$query = "SELECT * FROM buku WHERE 1=1";

if ($kategori !== 'Semua') {
    $query .= " AND NamaKategori = ?";
}
if ($tahunTerbit !== 'Semua') {
    $query .= " AND TahunTerbit = ?";
}

$stmt = $conn->prepare($query);

if ($kategori !== 'Semua' && $tahunTerbit !== 'Semua') {
    $stmt->bind_param("ss", $kategori, $tahunTerbit);
} elseif ($kategori !== 'Semua') {
    $stmt->bind_param("s", $kategori);
} elseif ($tahunTerbit !== 'Semua') {
    $stmt->bind_param("s", $tahunTerbit);
}

$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    echo '<div class="col-md-4">';
    echo '<div class="card BukuID-card">';
    echo '<div class="card-body">';
    echo '<img src="' . $row['foto'] . '" alt="' . $row['Judul'] . '" class="BukuID-foto">';
    echo '<h5 class="card-title">' . $row['Judul'] . '</h5>';
    echo '<p class="card-text"><strong>Penulis:</strong> ' . $row['Penulis'] . '</p>';
    echo '<p class="card-text"><strong>Penerbit:</strong> ' . $row['Penerbit'] . '</p>';
    echo '<p class="card-text"><strong>Tahun Terbit:</strong> ' . $row['TahunTerbit'] . '</p>';
    echo '<p class="card-text"><strong>Kategori:</strong> ' . $row['NamaKategori'] . '</p>';
    echo '<a href="peminjamanuser.php?BukuID=' . $row['BukuID'] . '" class="btn btn-info w-100">Lihat Buku</a>';
    echo '</div></div></div>';
}

$stmt->close();
?>
