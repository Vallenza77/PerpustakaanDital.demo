<?php
session_start(); // Mulai sesi

// Cek apakah pengguna sudah login
if (!isset($_SESSION['UserID'])) {
    // Jika belum login, redirect ke halaman login
    header("Location: loginadmin.php");
    exit();
}

// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "db_perpustakaan");

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data pengguna dari database
$UserID = $_SESSION['UserID'];
$sql = "SELECT username, email, namalengkap, alamat FROM user WHERE UserID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $UserID);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "Data pengguna tidak ditemukan.";
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Pengguna</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f2f5;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }

        .container h1 {
            text-align: center;
            color: #007bff;
            margin-bottom: 30px;
        }

        .profile-info {
            list-style: none;
            padding: 0;
            margin-bottom: 20px;
        }

        .profile-info li {
            padding: 10px 15px;
            border-bottom: 1px solid #e9ecef;
            font-size: 18px;
        }

        .profile-info span {
            font-weight: bold;
            color: #495057;
        }

        .actions {
            text-align: center;
        }

        .actions a {
            text-decoration: none;
            color: white;
            background: #007bff;
            padding: 10px 20px;
            border-radius: 8px;
            margin: 10px;
            display: inline-block;
            transition: background 0.3s;
        }

        .actions a:hover {
            background: #0056b3;
        }

        .btn-collection {
            background: #28a745;
        }

        .btn-collection:hover {
            background: #218838;
        }

        @media (max-width: 576px) {
            .container {
                padding: 15px;
            }

            .profile-info li {
                font-size: 16px;
            }

            .actions a {
                padding: 8px 15px;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Profil Pengguna</h1>
        <ul class="profile-info">
            <li><span>Username:</span> <?= htmlspecialchars($user['username']); ?></li>
            <li><span>Email:</span> <?= htmlspecialchars($user['email']); ?></li>
            <li><span>Nama Lengkap:</span> <?= htmlspecialchars($user['namalengkap']); ?></li>
            <li><span>Alamat:</span> <?= nl2br(htmlspecialchars($user['alamat'])); ?></li>
        </ul>
        <div class="actions">
            <a href="editprofiluser.php" class="btn btn-primary">Edit Profil</a>
            <a href="dasboard.php" class="btn btn-secondary">Kembali ke Dashboard</a>
            <a href="koleksibuku.php" class="btn btn-collection">Lihat Koleksi Buku</a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
