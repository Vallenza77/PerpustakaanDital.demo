<?php
// Include the database connection file
include('koneksi.php');

// Check if a book return request is made
if (isset($_GET['return_id'])) {
    $peminjamanID = $_GET['return_id'];

    // Delete the borrowing record from the peminjaman table
    $deleteQuery = "DELETE FROM peminjaman WHERE PeminjamanID = $peminjamanID";
    if ($conn->query($deleteQuery)) {
        echo "<script>alert('Peminjaman berhasil dihapus'); window.location='databuku.php';</script>";
    } else {
        echo "<script>alert('Terjadi kesalahan saat menghapus peminjaman'); window.location='databuku.php';</script>";
    }
} else {
    echo "<script>alert('ID Peminjaman tidak ditemukan'); window.location='databuku.php';</script>";
}
?>
