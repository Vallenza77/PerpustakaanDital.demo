<?php
// Include the database connection file
include('koneksi.php');

// Fetch categories from the database
$categoryQuery = "SELECT * FROM kategoribuku";
$categoryResult = $conn->query($categoryQuery);

$categories = [];
if ($categoryResult) {
    while ($row = $categoryResult->fetch_assoc()) {
        $categories[] = $row;
    }
} else {
    echo "Terjadi kesalahan dalam mengambil data kategori: " . $conn->error;
}

// Function to handle file upload
function uploadImage($foto) {
    $targetDir = "uploads/";
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    $targetFile = $targetDir . uniqid() . basename($foto['name']);
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    $check = getimagesize($foto['tmp_name']);
    if ($check === false) {
        echo "File is not an image.";
        return false;
    }

    if ($foto['size'] > 5000000) {
        echo "Sorry, your file is too large.";
        return false;
    }

    if (!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        return false;
    }

    if (move_uploaded_file($foto['tmp_name'], $targetFile)) {
        return $targetFile;
    } else {
        echo "Sorry, there was an error uploading your file.";
        return false;
    }
}

// Insert book into the database
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $Judul = $_POST['Judul'];
    $Penulis = $_POST['Penulis'];
    $Penerbit = $_POST['Penerbit'];
    $TahunTerbit = $_POST['TahunTerbit'];
    $NamaKategori = $_POST['NamaKategori'];
    $Deskripsi = $_POST['Deskripsi']; // Get the selected category

    $fotoPath = uploadImage($_FILES['foto']);
    if ($fotoPath) {
        $query = "INSERT INTO buku (Judul, Penulis, Penerbit, TahunTerbit, NamaKategori, Deskripsi ,foto) 
                  VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssssss", $Judul, $Penulis, $Penerbit, $TahunTerbit, $NamaKategori, $Deskripsi, $fotoPath);

        if ($stmt->execute()) {
            echo "<script>alert('Buku berhasil ditambahkan'); window.location.href='bukuadmin.php';</script>";
        } else {
            echo "Terjadi kesalahan: " . $stmt->error;
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
        }

        /* Sidebar */
        #sidebar {
            width: 250px;
            background-color: #343a40;
            color: white;
            height: 100vh;
            padding: 20px;
            position: fixed;
            transition: all 0.3s;
        }

        #sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px;
            border-radius: 5px;
            transition: background 0.3s;
        }

        #sidebar a:hover {
            background: #495057;
        }

        /* Content */
        #content {
            margin-left: 250px;
            padding: 40px;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        /* Form Styling */
        .card {
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
        }

        /* Button */
        .btn-primary {
            background: #007bff;
            border: none;
            transition: background 0.3s;
        }

        .btn-primary:hover {
            background: #0056b3;
        }

        /* Responsive */
        @media (max-width: 768px) {
            #sidebar {
                width: 200px;
            }

            #content {
                margin-left: 200px;
                padding: 20px;
            }
        }

        @media (max-width: 576px) {
            #sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            #content {
                margin-left: 0;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
<!-- Sidebar -->
<div id="sidebar">
    <h4>Menu Admin</h4>
    <ul class="list-unstyled">
        <li><a href="bukuadmin.php">📚 Daftar Buku</a></li>
        <li><a href="penambahanbuku.php">➕ Tambah Buku</a></li>
        <li><a href="dasboardadmin.php">🚪 Keluar</a></li>
    </ul>
</div>
<div id="content">
    <div class="container">
        <h1>Tambah Buku</h1>
        <form method="POST" action="" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="Judul" class="form-label">Judul Buku</label>
                <input type="text" id="Judul" name="Judul" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="Penulis" class="form-label">Penulis</label>
                <input type="text" id="Penulis" name="Penulis" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="Penerbit" class="form-label">Penerbit</label>
                <input type="text" id="Penerbit" name="Penerbit" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="TahunTerbit" class="form-label">Tahun Terbit</label>
                <input type="date" id="TahunTerbit" name="TahunTerbit" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="NamaKategori" class="form-label">Kategori Buku</label>
                <select id="NamaKategori" name="NamaKategori" class="form-control" required>
                    <option value="">Pilih Kategori</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['NamaKategori']; ?>">
                            <?php echo $category['NamaKategori']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="Deskripsi" class="form-label">Deskripsi</label>
                <input type="text" id="Deskripsi" name="Deskripsi" class="form-control" required>
            </div>

            <div class="mb-3">
                <label for="foto" class="form-label">Upload Gambar Buku</label>
                <input type="file" id="foto" name="foto" class="form-control" required>
            </div>

            <button type="submit" class="btn btn-primary">Tambah Buku</button>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>  