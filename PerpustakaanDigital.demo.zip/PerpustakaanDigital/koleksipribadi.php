<?php
session_start();

// Memeriksa apakah pengguna sudah login
if (!isset($_SESSION['UserID'])) {
    echo "Silakan login terlebih dahulu.";
    exit();
}

// Include koneksi ke database
include('koneksi.php');

// Menambahkan buku ke koleksi pribadi
if (isset($_POST['BukuID'])) {
    $BukuID = $_POST['BukuID'];
    $UserID = $_SESSION['UserID'];  // Mengambil ID pengguna dari sesi

    // Periksa apakah buku sudah ada di koleksi pribadi
    $query = "SELECT * FROM koleksipribadi WHERE BukuID = ? AND UserID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $BukuID, $UserID);
    
    if ($stmt->execute()) {
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            echo "Buku ini sudah ada di koleksi pribadi Anda.";
        } else {
            // Menambahkan buku ke koleksi pribadi jika belum ada
            $insertQuery = "INSERT INTO koleksipribadi (BukuID, UserID) VALUES (?, ?)";
            $insertStmt = $conn->prepare($insertQuery);
            $insertStmt->bind_param("ii", $BukuID, $UserID);

            if ($insertStmt->execute()) {
                echo "Buku berhasil ditambahkan ke koleksi pribadi Anda!";
            } else {
                echo "Terjadi kesalahan saat menambahkan buku ke koleksi pribadi.";
            }
        }
    } else {
        echo "Terjadi kesalahan saat memeriksa koleksi pribadi.";
    }

    $stmt->close();
    $conn->close();
} 

// Menghapus buku dari koleksi pribadi
if (isset($_POST['deleteKoleksiID'])) {
    $KoleksID = $_POST['deleteKoleksiID'];  // ID koleksi yang akan dihapus
    
    // Hapus koleksi dari tabel koleksi pribadi
    $deleteQuery = "DELETE FROM koleksipribadi WHERE KoleksID = ?";
    $deleteStmt = $conn->prepare($deleteQuery);
    $deleteStmt->bind_param("i", $KoleksID);

    if ($deleteStmt->execute()) {
        echo "Buku berhasil dihapus dari koleksi pribadi.";
    } else {
        echo "Terjadi kesalahan saat menghapus buku dari koleksi pribadi.";
    }

    $deleteStmt->close();
    $conn->close();
}
?>
