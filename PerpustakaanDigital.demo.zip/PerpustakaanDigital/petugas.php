<?php
// Include the database connection file
include('koneksi.php');

// Query to count total books
$query = "SELECT COUNT(*) AS total_buku FROM buku";
$result = $conn->query($query);
$totalBuku = 0;

// Check if query is successful
if ($result) {
    $row = $result->fetch_assoc();
    $totalBuku = $row['total_buku'];
}

// Query to count total users who are borrowing books
$queryPeminjam = "SELECT COUNT(*) AS total_peminjam FROM peminjaman WHERE StatusPeminjaman = 'Dipinjam'";
$resultPeminjam = $conn->query($queryPeminjam);
$totalPeminjam = 0;
if ($resultPeminjam) {
    $row = $resultPeminjam->fetch_assoc();
    $totalPeminjam = $row['total_peminjam'];
}

// Fetch books and reviews from the database
$queryBuku = "SELECT * FROM buku";
$resultBuku = $conn->query($queryBuku);

$books = [];
if ($resultBuku) {
    while ($row = $resultBuku->fetch_assoc()) {
        $books[] = $row;
    }
} else {
    echo "Terjadi kesalahan dalam mengambil data buku: " . $conn->error;
}

// Fetch reviews for each book
$reviews = [];
foreach ($books as $book) {
    $BukuID = $book['BukuID'];
    $queryReviews = "SELECT * FROM ulasanbuku WHERE BukuID = $BukuID";
    $resultReviews = $conn->query($queryReviews);
    $bookReviews = [];
    if ($resultReviews) {
        while ($review = $resultReviews->fetch_assoc()) {
            $bookReviews[] = $review;
        }
    }
    $reviews[$BukuID] = $bookReviews;
}

// Query to get the peminjaman records (book borrowings)
$queryPeminjaman = "SELECT peminjaman.PeminjamanID, peminjaman.UserID, buku.Judul, peminjaman.TanggalPeminjaman, peminjaman.TanggalPengembalian, peminjaman.StatusPeminjaman 
                    FROM peminjaman 
                    INNER JOIN buku ON peminjaman.BukuID = buku.BukuID 
                    WHERE peminjaman.StatusPeminjaman = 'Dipinjam'"; // Only get borrowed books
$resultPeminjaman = $conn->query($queryPeminjaman);

$peminjamanRecords = [];
if ($resultPeminjaman) {
    while ($row = $resultPeminjaman->fetch_assoc()) {
        $peminjamanRecords[] = $row;
    }
} else {
    echo "Terjadi kesalahan dalam mengambil data peminjaman: " . $conn->error;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link rel="icon" href="/favicon.png">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome for Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            height: 100vh;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #004085;
            padding-top: 20px;
            color: white;
        }
        .sidebar a {
            padding: 15px 20px;
            display: block;
            color: white;
            text-decoration: none;
            transition: background-color 0.2s;
        }
        .sidebar a:hover {
            background-color: #0056b3;
        }
        .main-content {
            margin-left: 250px;
            padding: 5px;
        }
        .navbar {
            background-color: #004085;
            color: white;
        }
        .navbar-brand, .navbar-nav .nav-link {
            color: white;
        }
        .navbar-nav .nav-link:hover {
            color: #0056b3;
        }
        .card {
            border-radius: 10px;
        }
        .card-body {
            padding: 15px;
        }
        .card-title {
            font-size: 1.25rem;
        }
        .card-text {
            font-size: 1rem;
        }
        .card-text2 {
            font-size: 3rem;
        }
        .card-img-top {
            object-fit: cover;
            height: 200px;
            border-radius: 10px 10px 0 0;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h3 class="text-center">ADMIN</h3>
       
        <a href="bukuadmin.php">Manajemen Buku</a>
        <a href="kategoribuku.php">Kategori Buku</a>
        <a href="databuku.php">Data Buku</a>
        <a href="dataulasan.php">Data ulasan</a>
       
        <a href="logoutadmin.php">Keluar</a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-dark">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">Dashboard</a>
                
                <div class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-user-circle"></i> Admin <!-- Replace with dynamic username if needed -->
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="userDropdown">
                        <li><a class="dropdown-item" href="profiladmin.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                        <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cogs"></i> Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logoutadmin.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <!-- Content -->
        <div class="container mt-4">
            <h1>Selamat Datang </h1>
            <p class="lead">Dashboard utama untuk mengelola perpustakaan digital Anda.</p>

            <!-- Statistik -->
            <div class="row">
                <div class="col-md-4">
                    <div class="card text-white bg-primary mb-3">
                        <div class="card-body">
                            <h5 class="card-title">Total Buku</h5>
                            <p class="card-text2 display-4"><?php echo $totalBuku; ?></p> <!-- Display total books -->
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card text-white bg-primary mb-3">
                        <div class="card-body">
                            <h5 class="card-title">Peminjam Buku</h5>
                            <p class="card-text2 display-4"><?php echo $totalPeminjam; ?></p> <!-- Display total borrowers -->
                        </div>
                    </div>
                </div>
                

            <h1>Daftar Buku</h1>
            <div class="row">
                <?php if (!empty($books)): ?>
                    <?php foreach ($books as $book): ?>
                        <div class="col-md-3">
                            <div class="card">
                                <img src="<?php echo $book['foto']; ?>" alt="<?php echo $book['Judul']; ?>" class="card-img-top">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo $book['Judul']; ?></h5>
                                    <p class="card-text"><strong>Penulis:</strong> <?php echo $book['Penulis']; ?></p>
                                    <p class="card-text"><strong>Penerbit:</strong> <?php echo $book['Penerbit']; ?></p>
                                    <p class="card-text"><strong>Tahun Terbit:</strong> <?php echo $book['TahunTerbit']; ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="text-center">Tidak ada buku yang tersedia.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
