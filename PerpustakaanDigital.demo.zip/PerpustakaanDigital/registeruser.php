<?php
// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "db_perpustakaan");

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data dari form
$UserID = uniqid('UserID');
$username = isset($_POST['username']) ? $_POST['username'] : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';
$email = isset($_POST['email']) ? $_POST['email'] : '';
$namalengkap = isset($_POST['namalengkap']) ? $_POST['namalengkap'] : '';
$alamat = isset($_POST['alamat']) ? $_POST['alamat'] : '';

// Variabel untuk pesan
$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!empty($username) && !empty($password) && !empty($email) && !empty($namalengkap) && !empty($alamat)) {
        // Jika semua data terisi, simpan ke database
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO user (UserID, username, password, email, namalengkap, alamat) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $UserID, $username, $hashed_password, $email, $namalengkap, $alamat);

        if ($stmt->execute()) {
            $message = "Register berhasil! <a href='loginuser.php'>Login</a>";
        } else {
            $message = "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        // Jika data tidak lengkap, beri tahu pengguna
        $message = "Harap isi semua data!";
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Registrasi</title>
    <style>
        /* Reset and base styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f1f1f1;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            padding: 20px;
        }

        /* Register Container */
        .register-container {
            background-color: #fff;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 550px;
            text-align: center;
        }

        /* Heading */
        h2 {
            font-size: 32px;
            color: #333;
            margin-bottom: 20px;
            font-weight: bold;
        }

        /* Table Style */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        td {
            padding: 12px 10px;
            vertical-align: middle;
            text-align: left;
        }

        label {
            font-size: 16px;
            color: #555;
            font-weight: 500;
        }

        /* Input and Textarea Style */
        input[type="text"],
        input[type="password"],
        input[type="email"],
        textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            margin-top: 8px;
            transition: border 0.3s ease, box-shadow 0.3s ease;
        }

        /* Focus effect on input fields */
        input[type="text"]:focus,
        input[type="password"]:focus,
        input[type="email"]:focus,
        textarea:focus {
            border-color: #4caf50;
            box-shadow: 0 0 8px rgba(76, 175, 80, 0.3);
        }

        /* Textarea specific styling */
        textarea {
            resize: vertical;
            min-height: 100px;
        }

        /* Button Style */
        button {
            background-color: #4caf50;
            color: white;
            font-size: 16px;
            padding: 12px 20px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
            transition: background-color 0.3s ease;
        }

        /* Hover and active state for button */
        button:hover {
            background-color: #45a049;
        }

        button:active {
            background-color: #388e3c;
        }

        /* Link Styling (for login redirection) */
        a {
            color: #4caf50;
            font-weight: bold;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
            color: #388e3c;
        }

        /* Message Style */
        .message {
            margin-top: 20px;
            color: #f44336;
        }

        .message a {
            color: #4caf50;
        }
    </style>
</head>

<body>
    <div class="register-container">
        <h2>Registrasi Pengguna</h2>
        <form action="registeruser.php" method="POST">
            <table>
                <tr>
                    <td><label for="username">Username:</label></td>
                    <td><input type="text" id="username" name="username" required></td>
                </tr>
                <tr>
                    <td><label for="password">Password:</label></td>
                    <td><input type="password" id="password" name="password" required></td>
                </tr>
                <tr>
                    <td><label for="email">Email:</label></td>
                    <td><input type="email" id="email" name="email" required></td>
                </tr>
                <tr>
                    <td><label for="namalengkap">Nama Lengkap:</label></td>
                    <td><input type="text" id="namalengkap" name="namalengkap" required></td>
                </tr>
                <tr>
                    <td><label for="alamat">Alamat:</label></td>
                    <td><textarea id="alamat" name="alamat" rows="4" required></textarea></td>
                </tr>
            </table>
            <button type="submit">Register</button>
        </form>

        <!-- Display message below the form -->
        <?php if (!empty($message)): ?>
            <div class="message"><?php echo $message; ?></div>
        <?php endif; ?>
    </div>
</body>

</html>
