<?php
session_start(); // Pastikan session dimulai di bagian paling atas

// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "db_perpustakaan");

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data dari form login
$username = isset($_POST['username']) ? $_POST['username'] : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

// Jika data login dikirimkan
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Query untuk mencari username di database
    $stmt = $conn->prepare("SELECT UserID, username, password FROM user WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    // Jika username ditemukan
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Verifikasi password
        if (password_verify($password, $user['password'])) {
            // Login berhasil, buat sesi untuk menyimpan data pengguna
            $_SESSION['UserID'] = $user['UserID'];
            $_SESSION['username'] = $user['username'];

            // Redirect ke dashboard
            header("Location: dasboard.php");
            exit();
        } else {
            // Password salah
            $message = "Password salah!";
        }
    } else {
        // Username tidak ditemukan
        $message = "Username tidak ditemukan!";
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        /* CSS untuk styling login */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-image: url('img/');
            font-family: 'Arial', sans-serif;
            background: linear-gradient(to right, #42a5f5, #1e88e5);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-container {
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }

        h2 {
            margin-bottom: 20px;
            color: #1e88e5;
            font-size: 26px;
            font-weight: bold;
        }

        .form-group {
            margin-bottom: 15px;
            text-align: left;
        }

        label {
            font-size: 14px;
            color: #333;
            display: inline-block;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 2px solid #42a5f5;
            border-radius: 5px;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: #1e88e5;
            box-shadow: 0 0 8px rgba(30, 136, 229, 0.4);
        }

        button {
            width: 100%;
            padding: 12px;
            font-size: 16px;
            color: white;
            background-color: #1e88e5;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 15px;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        button:hover {
            background-color: #1565c0;
            transform: translateY(-2px);
        }

        button:active {
            background-color: #0d47a1;
            transform: translateY(2px);
        }

        .register-link {
            color: #42a5f5;
            text-decoration: none;
            font-size: 14px;
            font-weight: bold;
        }

        .register-link:hover {
            color: #1e88e5;
            text-decoration: underline;
        }

        .error-message {
            color: red;
            font-size: 14px;
            margin-top: 10px;
        }
    </style>
</head>

<body>
    <div class="login-container">
        <h2>Login</h2>
        <form action="loginuser.php" method="POST">
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit">Login</button>
        </form>

        <?php if (isset($message)) { echo "<p class='error-message'>$message</p>"; } ?>

        <p>Tidak Punya Akun? <a href="registeruser.php" class="register-link">Register</a></p>
    </div>
</body>
</html>
