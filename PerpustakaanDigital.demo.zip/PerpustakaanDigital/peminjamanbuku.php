<?php
// Koneksi ke database
include('koneksi.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Mengambil data dari form
    $judul = $_POST['Judul'];
    $penulis = $_POST['Penulis'];
    $penerbit = $_POST['Penerbit'];
    $tahunTerbit = $_POST['TahunTerbit'];
    $foto = $_POST['Foto']; // Anda bisa mengubah ini sesuai dengan input file atau URL gambar

    // Menyisipkan data ke database
    $query = "INSERT INTO buku (Judul, Penulis, Penerbit, TahunTerbit, foto) 
              VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        die("Kesalahan prepare statement: " . $conn->error);
    }

    $stmt->bind_param("sssis", $judul, $penulis, $penerbit, $tahunTerbit, $foto);

    if ($stmt->execute()) {
        echo "Buku berhasil ditambahkan!";
    } else {
        echo "Kesalahan saat menambahkan buku: " . $stmt->error;
    }

    $stmt->close();
}
?>
