<?php
// Include the database connection file
include('koneksi.php');

// Function to handle file upload
function uploadImage($foto) {
    $targetDir = "uploads/"; // Directory to save the uploaded foto
    if (!is_dir('uploads')) {
        mkdir('uploads', 0777, true); // Membuat folder dengan izin 777 jika belum ada
    }

    // Generate a unique filename by appending a timestamp
    $targetFile = $targetDir . uniqid() . basename($foto['name']); // Create a unique file name
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION)); // Get file extension

    // Check if file is an image
    $check = getimagesize($foto['tmp_name']); // Check the temporary file
    if ($check === false) {
        echo "File is not an image.";
        return false;
    }

    // Check file size (max 5MB)
    if ($foto['size'] > 5000000) {
        echo "Sorry, your file is too large.";
        return false;
    }

    // Allow certain file formats
    if (!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        return false;
    }

    // Try to upload the file
    if (move_uploaded_file($foto['tmp_name'], $targetFile)) {
        return $targetFile; // Return the file path after uploading
    } else {
        echo "Sorry, there was an error uploading your file.";
        return false;
    }
}

// Insert book into the database (if form is submitted)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $Judul = isset($_POST['Judul']) ? $_POST['Judul'] : '';
    $Penulis = isset($_POST['Penulis']) ? $_POST['Penulis'] : '';
    $Penerbit = isset($_POST['Penerbit']) ? $_POST['Penerbit'] : '';
    $TahunTerbit = isset($_POST['TahunTerbit']) ? $_POST['TahunTerbit'] : '';
    
    // Handle foto upload
    if (isset($_FILES['foto'])) {
        $imagePath = uploadImage($_FILES['foto']); // Ensure you pass $_FILES['foto']
    }

    // If the foto upload is successful, insert the data into the database
    if (isset($imagePath) && $imagePath) {
        $query = "INSERT INTO buku (Judul, Penulis, Penerbit, TahunTerbit, foto) 
                  VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssss", $Judul, $Penulis, $Penerbit, $TahunTerbit, $imagePath);

        if ($stmt->execute()) {
            echo "<script>alert('Buku berhasil ditambahkan'); window.location.href='buku.php';</script>";
        } else {
            echo "Terjadi kesalahan: " . $stmt->error;
        }

        $stmt->close();
    }
}

// Fetch books from the database
$query = "SELECT * FROM buku";
$result = $conn->query($query);

// Store books in an array
$books = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $books[] = $row; // This includes BukuID in each row
    }
} else {
    echo "Terjadi kesalahan dalam mengambil data buku: " . $conn->error;
}

// Filter books by category (if any filters are applied)
$categoryFilter1 = isset($_GET['categoryFilter1']) ? $_GET['categoryFilter1'] : '';
$categoryFilter2 = isset($_GET['categoryFilter2']) ? $_GET['categoryFilter2'] : '';
$categoryFilter3 = isset($_GET['categoryFilter3']) ? $_GET['categoryFilter3'] : '';

// Function to filter books based on the selected categories
function loadBooks($books, $categoryFilter1, $categoryFilter2, $categoryFilter3) {
    return array_filter($books, function($book) use ($categoryFilter1, $categoryFilter2, $categoryFilter3) {
        $matchesCategory1 = $categoryFilter1 ? $book['Kategori'] === $categoryFilter1 : true;
        $matchesCategory2 = $categoryFilter2 ? $book['Kategori'] === $categoryFilter2 : true;
        $matchesCategory3 = $categoryFilter3 ? $book['Kategori'] === $categoryFilter3 : true;
        return $matchesCategory1 && $matchesCategory2 && $matchesCategory3;
    });
}

// Apply filters
$filteredBooks = loadBooks($books, $categoryFilter1, $categoryFilter2, $categoryFilter3);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .book-card {
            margin-bottom: 20px;
        }
        .recommendation-card {
            cursor: pointer;
        }
        .recommendation-card:hover {
            opacity: 0.8;
        }
        .book-foto {
            width: 100%;
            height: 500px;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <div class="container my-5">
        <h1 class="text-center mb-4">Daftar Buku</h1>

        <!-- Form Pencarian dan Filter -->
        <div class="d-flex justify-content-center mb-4">
            <form method="GET" class="d-flex">
                <div class="me-3">
                    <select class="form-select" name="categoryFilter1">
                        <option value="">Semua Kategori</option>
                        <option value="Fiksi" <?php echo ($categoryFilter1 == 'Fiksi' ? 'selected' : ''); ?>>Fiksi</option>
                        <option value="Non-Fiksi" <?php echo ($categoryFilter1 == 'Non-Fiksi' ? 'selected' : ''); ?>>Non-Fiksi</option>
                        <option value="Sains" <?php echo ($categoryFilter1 == 'Sains' ? 'selected' : ''); ?>>Sains</option>
                    </select>
                </div>
                <div class="me-3">
                    <select class="form-select" name="categoryFilter2">
                        <option value="">Semua Kategori</option>
                        <option value="Fiksi" <?php echo ($categoryFilter2 == 'Fiksi' ? 'selected' : ''); ?>>Fiksi</option>
                        <option value="Non-Fiksi" <?php echo ($categoryFilter2 == 'Non-Fiksi' ? 'selected' : ''); ?>>Non-Fiksi</option>
                        <option value="Sains" <?php echo ($categoryFilter2 == 'Sains' ? 'selected' : ''); ?>>Sains</option>
                    </select>
                </div>
                <div class="me-3">
                    <select class="form-select" name="categoryFilter3">
                        <option value="">Semua Kategori</option>
                        <option value="Fiksi" <?php echo ($categoryFilter3 == 'Fiksi' ? 'selected' : ''); ?>>Fiksi</option>
                        <option value="Non-Fiksi" <?php echo ($categoryFilter3 == 'Non-Fiksi' ? 'selected' : ''); ?>>Non-Fiksi</option>
                        <option value="Sains" <?php echo ($categoryFilter3 == 'Sains' ? 'selected' : ''); ?>>Sains</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Filter</button>
            </form>
        </div>

        <!-- Daftar Buku -->
        <div class="row" id="bookList">
            <?php foreach ($filteredBooks as $index => $book): ?>
                <div class="col-md-4">
                    <a href="ulasanbuku.php?title=<?php echo urlencode($book['Judul']); ?>" class="text-decoration-none">
                    <form method="POST" enctype="multipart/form-data">
                        <div class="card book-card">
                            <div class="card-body">
                            <img src="<?php echo $book['foto']; ?>" alt="<?php echo $book['Judul']; ?>" class="book-foto">
                                <h5 class="card-title"><?php echo $book['Judul']; ?></h5>
                                <p class="card-text"><strong>Penulis:</strong> <?php echo $book['Penulis']; ?></p>
                                <p class="card-text"><strong>Penerbit:</strong> <?php echo $book['Penerbit']; ?></p>
                                <p class="card-text"><strong>Tahun Terbit:</strong> <?php echo $book['TahunTerbit']; ?></p>
                             
                                <button class="btn btn-primary">Pinjam</button>
                            </div>
                        </div>
                        </form>
                    </a>
                </div>
            <?php endforeach; ?>
        </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
