<?php
// Set konfigurasi koneksi ke database
$host = "localhost"; // Nama host, biasanya localhost
$user = "root"; // Nama pengguna database
$password = ""; // Password pengguna database (kosong untuk default di XAMPP)
$dbname = "db_perpustakaan"; // Nama database

// Membuat koneksi
$conn = new mysqli($host, $user, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
} else {
    //echo "Koneksi berhasil"; // Jika koneksi berhasil, bisa menampilkan pesan ini
}
?>

