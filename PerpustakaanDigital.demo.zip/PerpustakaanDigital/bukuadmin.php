<?php
// Include the database connection file
include('koneksi.php');

// Function to handle file upload
function uploadImage($foto) {
    $targetDir = "uploads/"; // Directory to save the uploaded foto
    if (!is_dir('uploads')) {
        mkdir('uploads', 0777, true); // Membuat folder dengan izin 777 jika belum ada
    }

    $targetFile = $targetDir . uniqid() . basename($foto['name']); // Create a unique file name
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION)); // Get file extension

    $check = getimagesize($foto['tmp_name']);
    if ($check === false) {
        echo "File is not an image.";
        return false;
    }

    if ($foto['size'] > 5000000) {
        echo "Sorry, your file is too large.";
        return false;
    }

    if (!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        return false;
    }

    if (move_uploaded_file($foto['tmp_name'], $targetFile)) {
        return $targetFile;
    } else {
        echo "Sorry, there was an error uploading your file.";
        return false;
    }
}

// Fetch books from the database with optional search filter
$search = isset($_GET['search']) ? $_GET['search'] : '';
$query = "SELECT * FROM buku";

if (!empty($search)) {
    $query .= " WHERE Judul LIKE ?";
}

// Prepare the statement
$stmt = $conn->prepare($query);

// Check if the statement preparation failed
if ($stmt === false) {
    die('Error in preparing statement: ' . $conn->error);
}

if (!empty($search)) {
    $searchParam = "%$search%";
    $stmt->bind_param("s", $searchParam);
}

$stmt->execute();

// Check if execution failed
if ($stmt === false) {
    die('Error in executing statement: ' . $stmt->error);
}

$result = $stmt->get_result();

$books = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $books[] = $row;
    }
} else {
    echo "Terjadi kesalahan dalam mengambil data buku: " . $conn->error;
}
$stmt->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
        }

        #sidebar {
            width: 250px;
            background-color: #343a40;
            color: white;
            height: 100vh;
            position: fixed;
            padding: 20px;
            transition: all 0.3s;
        }

        #sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px;
            border-radius: 5px;
            transition: background 0.3s;
        }

        #sidebar a:hover {
            background: #495057;
        }

        #content {
            margin-left: 250px;
            padding: 40px;
        }

        .book-card {
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
        }

        .book-card:hover {
            transform: scale(1.02);
        }

        .book-img {
            width: 100%;
            height: 250px;
            object-fit: cover;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
        }

        .btn-primary:hover {
            background: #0056b3;
        }

        @media (max-width: 768px) {
            #sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }

            #content {
                margin-left: 0;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div id="sidebar">
        <h4>📚 Menu Admin</h4>
        <ul class="list-unstyled">
            <li><a href="bukuadmin.php">📖 Daftar Buku</a></li>
            <li><a href="penambahanbuku.php">➕ Tambah Buku</a></li>
            <li><a href="dasboardadmin.php">🚪 Keluar</a></li>
        </ul>
    </div>

    <div id="content">
        <h1 class="mb-4">Daftar Buku</h1>

        <form method="GET" action="" class="mb-4">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Cari buku berdasarkan judul" value="<?php echo htmlspecialchars($search); ?>">
                <button class="btn btn-primary" type="submit">Cari</button>
            </div>
        </form>

        <div class="row">
            <?php if (!empty($books)): ?>
                <?php foreach ($books as $book): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card book-card">
                            <img src="<?php echo $book['foto']; ?>" alt="<?php echo $book['Judul']; ?>" class="book-img">
                            <div class="card-body">
                                <h5 class="card-title">Judul: <?php echo $book['Judul']; ?></h5>
                                <p class="card-text"><strong>Penulis:</strong> <?php echo $book['Penulis']; ?></p>
                                <p class="card-text"><strong> Penerbit:</strong> <?php echo $book['Penerbit']; ?></p>
                                <p class="card-text"><strong> Tahun Terbit:</strong> <?php echo $book['TahunTerbit']; ?></p>
                                <p class="card-text"><strong> Kategori:</strong> <?php echo isset($book['NamaKategori']) ? $book['NamaKategori'] : 'Kategori tidak tersedia'; ?></p>
                                <p class="card-text"><strong> Deskripsi:</strong> <?php echo $book['Deskripsi']; ?></p>
                                <p class="card-text"><strong> Stok Buku:</strong> <?php echo $book['Stok']; ?></p>
                                <a href="edit.php?id=<?php echo $book['BukuID']; ?>" class="btn btn-warning">✏️ Edit</a>
                                <a href="bukuadmin.php?id=<?php echo $book['BukuID']; ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus buku ini?')">🗑 Hapus</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p class="text-center">Tidak ada buku yang ditemukan.</p>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
