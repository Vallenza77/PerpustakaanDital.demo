<?php

// Include database connection
include('koneksi.php');

// Handle book borrowing
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $UserID = $_POST['UserID']; // Replace with actual logged-in user ID
    $BukuID = $_POST['BukuID'];
    $TanggalPeminjaman = $_POST['TanggalPeminjaman'];
    $TanggalPengembalian = $_POST['TanggalPengembalian'];
    $StatusPeminjaman = 'Dipinjam'; // Status is always "Dipinjam" when borrowing

    // Check if dates are valid and TanggalPengembalian is after TanggalPeminjaman
    if (empty($TanggalPeminjaman) || empty($TanggalPengembalian)) {
        echo "<script>alert('Tanggal Peminjaman dan Tanggal Pengembalian tidak boleh kosong'); window.history.back();</script>";
        exit;
    }

    if ($TanggalPengembalian < $TanggalPeminjaman) {
        echo "<script>alert('Tanggal Pengembalian harus setelah Tanggal Peminjaman'); window.history.back();</script>";
        exit;
    }

    // Insert data into the database
    $query = "INSERT INTO peminjaman (UserID, BukuID, TanggalPeminjaman, TanggalPengembalian, StatusPeminjaman) 
              VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    if ($stmt === false) {
        echo "<script>alert('Terjadi kesalahan saat mempersiapkan query'); window.history.back();</script>";
        exit;
    }

    $stmt->bind_param("iisss", $UserID, $BukuID, $TanggalPeminjaman, $TanggalPengembalian, $StatusPeminjaman);

    if ($stmt->execute()) {
        echo "<script>alert('Peminjaman berhasil'); window.location.href='peminjamanuser.php';</script>";
    } else {
        echo "<script>alert('Terjadi kesalahan: " . $stmt->error . "'); window.history.back();</script>";
    }

    $stmt->close();
}
?>
