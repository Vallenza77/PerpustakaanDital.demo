<?php
// Sertakan koneksi ke database
include('koneksi.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['KategoriID'])) {
    $kategoriID = intval($_POST['KategoriID']);

    // Cek apakah ID kategori ada di database
    $checkQuery = "SELECT * FROM kategoribuku WHERE KategoriID = ?";
    $stmtCheck = $conn->prepare($checkQuery);
    $stmtCheck->bind_param("i", $kategoriID);
    $stmtCheck->execute();
    $resultCheck = $stmtCheck->get_result();

    if ($resultCheck->num_rows > 0) {
        // Hapus kategori dari database
        $deleteQuery = "DELETE FROM kategoribuku WHERE KategoriID = ?";
        $stmtDelete = $conn->prepare($deleteQuery);
        $stmtDelete->bind_param("i", $kategoriID);

        if ($stmtDelete->execute()) {
            // Perbaiki urutan ID setelah penghapusan
            $conn->query("SET @num := 0");
            $conn->query("UPDATE kategoribuku SET KategoriID = (@num := @num + 1) ORDER BY KategoriID");
            $conn->query("ALTER TABLE kategoribuku AUTO_INCREMENT = 1");

            echo "Kategori berhasil dihapus dan ID diperbarui.";
        } else {
            echo "Gagal menghapus kategori: " . $conn->error;
        }
    } else {
        echo "Kategori tidak ditemukan.";
    }
} else {
    echo "Permintaan tidak valid.";
}
?>
