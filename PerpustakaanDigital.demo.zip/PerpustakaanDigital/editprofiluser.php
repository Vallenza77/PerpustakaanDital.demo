<?php
session_start(); // Mulai sesi

// Cek apakah pengguna sudah login
if (!isset($_SESSION['UserID'])) {
    header("Location: loginadmin.php");
    exit();
}

// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "db_perpustakaan");

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data pengguna dari database
$UserID = $_SESSION['UserID'];
$sql = "SELECT username, email, namalengkap, alamat FROM user WHERE UserID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $UserID);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "Data pengguna tidak ditemukan.";
    exit();
}

// Inisialisasi variabel untuk pesan
$message = "";

// Jika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = isset($_POST['username']) ? $_POST['username'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $namalengkap = isset($_POST['namalengkap']) ? $_POST['namalengkap'] : '';
    $alamat = isset($_POST['alamat']) ? $_POST['alamat'] : '';
    $newPassword = isset($_POST['newPassword']) ? $_POST['newPassword'] : '';
    $confirmPassword = isset($_POST['confirmPassword']) ? $_POST['confirmPassword'] : '';

    // Validasi input
    if (!empty($username) && !empty($email) && !empty($namalengkap) && !empty($alamat)) {
        // Update data pengguna di database
        $update_sql = "UPDATE user SET username = ?, email = ?, namalengkap = ?, alamat = ? WHERE UserID = ?";
        $update_stmt = $conn->prepare($update_sql);
        $update_stmt->bind_param("sssss", $username, $email, $namalengkap, $alamat, $UserID);

        if ($update_stmt->execute()) {
            $message = "Profil berhasil diperbarui!";
        } else {
            $message = "Terjadi kesalahan saat memperbarui profil: " . $conn->error;
        }

        $update_stmt->close();
    } else {
        $message = "Harap isi semua data!";
    }

    // Proses perubahan password
    if (!empty($newPassword) || !empty($confirmPassword)) {
        if ($newPassword === $confirmPassword) {
            // Hash password baru
            $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

            // Update password di database
            $updatePasswordSql = "UPDATE user SET password = ? WHERE UserID = ?";
            $updatePasswordStmt = $conn->prepare($updatePasswordSql);
            $updatePasswordStmt->bind_param("ss", $hashedPassword, $UserID);

            if ($updatePasswordStmt->execute()) {
                $message = "Password berhasil diperbarui!";
            } else {
                $message = "Terjadi kesalahan saat memperbarui password: " . $conn->error;
            }

            $updatePasswordStmt->close();
        } else {
            $message = "Password baru dan konfirmasi password tidak cocok!";
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profil</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f1f1f1;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-size: 14px;
            color: #555;
            margin-bottom: 5px;
            font-weight: bold;
        }

        input, textarea {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }

        textarea {
            resize: vertical;
        }

        button {
            background-color: #1e88e5;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #1565c0;
        }

        .message {
            text-align: center;
            margin-bottom: 20px;
            color: green;
        }

        .error {
            color: red;
        }

        .back-link {
            text-align: center;
            margin-top: 10px;
        }

        .back-link a {
            color: #1e88e5;
            text-decoration: none;
        }

        .back-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Edit Profil</h1>
        <?php if (!empty($message)): ?>
            <p class="message <?= strpos($message, 'berhasil') !== false ? '' : 'error'; ?>">
                <?= htmlspecialchars($message); ?>
            </p>
        <?php endif; ?>
        <form action="editprofiluser.php" method="POST">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" value="<?= htmlspecialchars($user['username']); ?>" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" value="<?= htmlspecialchars($user['email']); ?>" required>

            <label for="newPassword">Password Baru:</label>
            <input type="password" id="newPassword" name="newPassword">

            <label for="confirmPassword">Konfirmasi Password Baru:</label>
            <input type="password" id="confirmPassword" name="confirmPassword">

            <label for="namalengkap">Nama Lengkap:</label>
            <input type="text" id="namalengkap" name="namalengkap" value="<?= htmlspecialchars($user['namalengkap']); ?>" required>

            <label for="alamat">Alamat:</label>
            <textarea id="alamat" name="alamat" rows="4" required><?= htmlspecialchars($user['alamat']); ?></textarea>

            <button type="submit">Simpan Perubahan</button>
        </form>
        <div class="back-link">
            <a href="profiluser.php">Kembali ke Profil</a>
        </div>
    </div>
</body>

</html>
