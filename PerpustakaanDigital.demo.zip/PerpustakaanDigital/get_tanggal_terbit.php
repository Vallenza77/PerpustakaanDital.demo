<?php
include('koneksi.php');

if (isset($_POST['kategori'])) {
    $kategori = $_POST['kategori'];

    if ($kategori === 'Semua') {
        $query = "SELECT DISTINCT TahunTerbit FROM buku ORDER BY TahunTerbit DESC";
    } else {
        $query = "SELECT DISTINCT TahunTerbit FROM buku WHERE TahunTerbit = ? ORDER BY TahunTerbit DESC";
    }

    $stmt = $conn->prepare($query);

    if ($kategori !== 'Semua') {
        $stmt->bind_param("s", $kategori);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    echo '<option value="Semua">Semua Tahun</option>';
    while ($row = $result->fetch_assoc()) {
        echo '<option value="' . htmlspecialchars($row['TahunTerbit']) . '">' . htmlspecialchars($row['TahunTerbit']) . '</option>';
    }

    $stmt->close();
}
?>
