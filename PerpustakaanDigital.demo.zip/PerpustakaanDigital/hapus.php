<?php
// Include the database connection file
include('koneksi.php');

// Get the book ID from the URL
$BukuID = isset($_GET['id']) ? $_GET['id'] : '';

// Check if the book ID is provided
if ($BukuID) {
    // Fetch the book details first to get the foto path
    $query = "SELECT * FROM buku WHERE BukuID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $BukuID);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $book = $result->fetch_assoc();
        
        // Delete the image file from the server
        $imagePath = "uploads/" . $book['foto'];
        if (file_exists($imagePath)) {
            unlink($imagePath);
        }

        // Delete the book from the database
        $deleteQuery = "DELETE FROM buku WHERE BukuID = ?";
        $deleteStmt = $conn->prepare($deleteQuery);
        $deleteStmt->bind_param("i", $BukuID);

        if ($deleteStmt->execute()) {
            // 🆕 Reset ulang ID agar tetap berurutan
            $conn->query("SET @num := 0");
            $conn->query("UPDATE buku SET BukuID = @num := @num + 1 ORDER BY BukuID");
            $conn->query("ALTER TABLE buku AUTO_INCREMENT = 1");

            echo "<script>alert('Buku berhasil dihapus'); window.location.href='bukuadmin.php';</script>";
        } else {
            echo "Terjadi kesalahan: " . $deleteStmt->error;
        }

        $deleteStmt->close();
    } else {
        echo "Buku tidak ditemukan.";
    }

    $stmt->close();
} else {
    echo "ID Buku tidak diberikan.";
}

$conn->close();
?>
