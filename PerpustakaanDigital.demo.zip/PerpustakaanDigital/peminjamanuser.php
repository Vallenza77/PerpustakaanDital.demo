<?php
session_start();

// Memeriksa apakah pengguna sudah login
if (!isset($_SESSION['UserID'])) {
    header("Location: loginuser.php");
    exit();
}

// Mendapatkan username dari session
$username = $_SESSION['username'];

// Include koneksi ke database
include('koneksi.php');

// Periksa apakah BukuID dikirim melalui URL
if (isset($_GET['BukuID']) && !empty($_GET['BukuID'])) {
    $BukuID = intval($_GET['BukuID']);

    $query = "SELECT * FROM buku WHERE BukuID = ?";
    $stmt = $conn->prepare($query);

    if (!$stmt) {
        die("Kesalahan pada prepare statement: " . $conn->error);
    }

    $stmt->bind_param("i", $BukuID);

    if (!$stmt->execute()) {
        die("Kesalahan eksekusi: " . $stmt->error);
    }

    $result = $stmt->get_result();
    if ($result && $result->num_rows > 0) {
        $BukuID = $result->fetch_assoc();
    } else {
        die("Buku tidak ditemukan.");
    }

    $stmt->close();
} else {
    die("BukuID tidak valid.");
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perpustakaan Digital</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome for Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    <!-- JQuery (required for AJAX) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
    body {
        font-family: 'Arial', sans-serif;
        background-color: #f9f9f9;
        color: #333;
    }

    nav.navbar {
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }

    .navbar-brand {
        font-weight: bold;
        font-size: 1.5rem;
    }

    .card {
        border: none;
        border-radius: 12px;
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.1);
    }

    .card img {
        border-radius: 12px 0 0 12px;
        object-fit: cover;
        height: 100%;
    }

    .card .card-body h5 {
        font-weight: bold;
        color: #333;
    }

    .btn {
        transition: all 0.3s ease;
        border-radius: 8px;
    }

    .btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
    }

    .btn-secondary {
        background-color: #6c757d;
        color: #fff;
        border: none;
    }

    .btn-secondary:hover {
        background-color: #5a6268;
    }

    .btn-primary {
        background-color: #007bff;
        color: #fff;
        border: none;
    }

    .btn-primary:hover {
        background-color: #0056b3;
    }

    .btn-success {
        background-color: #28a745;
        border: none;
    }

    .btn-success:hover {
        background-color: #218838;
    }

    textarea {
        resize: none;
        border: 1px solid #ddd;
        border-radius: 8px;
        padding: 10px;
        transition: border-color 0.3s ease;
    }

    textarea:focus {
        border-color: #007bff;
        outline: none;
        box-shadow: 0 0 4px rgba(0, 123, 255, 0.4);
    }

    h1 {
        color: #343a40;
        font-size: 2rem;
        font-weight: bold;
    }
    .rating {
        display: flex;
        flex-direction: row-reverse; /* Bintang dimulai dari kanan */
        justify-content: left;
        gap: 5px;
    }

    .rating input {
        display: none; /* Sembunyikan input radio */
    }

    .rating label {
        font-size: 2rem;
        color: #ccc; /* Warna default bintang */
        cursor: pointer;
        transition: color 0.2s ease-in-out;
    }

    .rating label:hover,
    .rating label:hover ~ label {
        color: #ffc107; /* Warna hover (kuning) */
    }

    .rating input:checked ~ label {
        color: #ffc107; /* Warna bintang yang dipilih */
    }
/* Menambahkan gaya untuk tombol dengan ikon */
#addToCollectionButton {
    display: inline-flex;
    align-items: center;
    border-radius: 1px;
    padding: 5px 5px;
    background-color: white;
    color: grey;
    font-size: 40px;
    transition: background-color 0.3s ease;
    border: none;
}

#addToCollectionButton i {
    margin-right: 0px; /* Memberikan jarak antara ikon dan teks */
}

#addToCollectionButton:hover {
    background-color: white;
    cursor: pointer;
}

    
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand" href="dasboard.php">My Website</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link active" href="#">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Contact</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-user"></i> <?= $username; ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <li><a class="dropdown-item" href="profiluser2.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                        <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cogs"></i> Settings</a></li>
                        <li><a class="dropdown-item" href="history.php"><i class="fas fa-history"></i> Loan History</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logoutuser.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>



<div class="container my-5">
    <h1 class="text-center mb-4">Detail Buku</h1>
    <div class="card mx-auto" style="max-width: 850px;">
        <div class="row g-0">
            <div class="col-md-4">
                <img src="<?php echo $BukuID['foto']; ?>" alt="<?php echo $BukuID['Judul']; ?>" class="img-fluid rounded-start">
            </div>
            <div class="col-md-8">
                <div class="card-body">
                    <h5 class="card-title"><?php echo $BukuID['Judul']; ?></h5>
                    <p class="card-text"><strong>Penulis:</strong> <?php echo $BukuID['Penulis']; ?></p>
                    <p class="card-text"><strong>Penerbit:</strong> <?php echo $BukuID['Penerbit']; ?></p>
                    <p class="card-text"><strong>Tahun Terbit:</strong> <?php echo $BukuID['TahunTerbit']; ?></p>
                    <p class="card-text"><strong>Kategori:</strong> <?php echo isset($BukuID['NamaKategori']) ? $BukuID['NamaKategori'] : 'Kategori tidak tersedia'; ?></p>
                    <p class="card-text"><strong>Deskripsi Buku:</strong> <?php echo $BukuID['Deskripsi']; ?></p>
                     <!-- Tombol dengan ikon bookmark untuk menambah ke koleksi pribadi -->
<button type="button" class="btn btn-secondary mt-3" id="addToCollectionButton">
    <i class="fas fa-bookmark"></i> </button>

                </div>
            </div>
        </div>

        <div class="card-body">
            <h5 class="card-title">Formulir Peminjaman Buku</h5>
            <form method="POST" id="peminjamanForm">
                <div class="mb-3">
                    <label for="tanggalPeminjaman" class="form-label">Tanggal Peminjaman</label>
                    <input type="date" class="form-control" id="TanggalPeminjaman" name="TanggalPeminjaman" required>
                </div>
                <div class="mb-3">
                    <label for="tanggalPengembalian" class="form-label">Tanggal Pengembalian</label>
                    <input type="date" class="form-control" id="TanggalPengembalian" name="TanggalPengembalian" required>
                </div>
                <input type="hidden" name="StatusPeminjaman" value="Dipinjam">
                <input type="hidden" name="BukuID" value="<?php echo $BukuID['BukuID']; ?>">
                <input type="hidden" name="UserID" value="<?php echo $_SESSION['UserID']; ?>">
                <a href="dasboard.php" class="btn btn-secondary mt-3">Kembali ke dashboard</a>
                <button type="button" class="btn btn-secondary mt-3" id="showReviewForm">Berikan Ulasan</button>
         
                <button type="submit" class="btn btn-primary mt-3">Konfirmasi Peminjaman</button>
            </form>

            <div  id="bookDescription" style="display: none; margin-top: 20px;"><?php echo $BukuID['Deskripsi']; ?></p>
            </div>

            <div id="reviewForm" style="display: none; margin-top: 20px;">
                <h5 class="card-title">Formulir Ulasan Buku</h5>
                <form method="POST" id="ulasanForm">
                    <div class="mb-3">
                        <label for="Ulasan" class="form-label">Ulasan</label>
                        <textarea class="form-control" id="Ulasan" name="Ulasan" rows="4" required></textarea>
                    </div>
                    <div class="rating">
                        <input type="radio" id="star5" name="Rating" value="5" required />
                        <label for="star5" title="5 stars"><i class="fa fa-star"></i></label>

                        <input type="radio" id="star4" name="Rating" value="4" required />
                        <label for="star4" title="4 stars"><i class="fa fa-star"></i></label>

                        <input type="radio" id="star3" name="Rating" value="3" required />
                        <label for="star3" title="3 stars"><i class="fa fa-star"></i></label>

                        <input type="radio" id="star2" name="Rating" value="2" required />
                        <label for="star2" title="2 stars"><i class="fa fa-star"></i></label>

                        <input type="radio" id="star1" name="Rating" value="1" required />
                        <label for="star1" title="1 star"><i class="fa fa-star"></i></label>
                    </div>
                    <input type="hidden" name="BukuID" value="<?php echo $BukuID['BukuID']; ?>">
                    <input type="hidden" name="UserID" value="<?php echo $_SESSION['UserID']; ?>">
                    <button type="submit" class="btn btn-primary mt-3">Kirim Ulasan</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Event listener untuk form peminjaman
    $('#peminjamanForm').submit(function(event) {
        event.preventDefault();  // Mencegah form dikirim secara normal

        var formData = $(this).serialize();  // Mengambil data dari form

        $.ajax({
            url: 'peminjaman.php',  // URL pemrosesan form
            type: 'POST',
            data: formData,
            success: function(response) {
                // Jika sukses, tampilkan pesan sukses dan tetap di halaman yang sama
                alert('Peminjaman Buku berhasil dilakukan!');
                // Menyembunyikan form ulasan jika sudah berhasil melakukan peminjaman
                $('#reviewForm').show();  // Menampilkan form ulasan setelah peminjaman berhasil
                // Reset form peminjaman jika perlu
                $('#peminjamanForm')[0].reset();
            },
            error: function(xhr, status, error) {
                alert('Terjadi kesalahan, coba lagi nanti!');
            }
        });
    });
 // Elemen yang digunakan
 const toggleDescriptionButton = $('#toggleDescriptionButton');
    const bookDescription = $('#bookDescription');
    const showReviewFormButton = $('#showReviewForm');
    const reviewForm = $('#reviewForm');

    // Sembunyikan elemen di awal
    bookDescription.hide();
    reviewForm.hide();

    // Toggle Deskripsi Buku
    toggleDescriptionButton.click(function() {
        // Tutup form ulasan jika terbuka
        reviewForm.hide();
        showReviewFormButton.text('Tampilkan Form Ulasan');

        // Toggle deskripsi buku
        bookDescription.toggle();
        toggleDescriptionButton.text(bookDescription.is(':visible') ? 'Sembunyikan Deskripsi' : 'Tampilkan Deskripsi');
    });

    // Toggle Form Ulasan
    showReviewFormButton.click(function() {
        // Tutup deskripsi buku jika terbuka
        bookDescription.hide();
        toggleDescriptionButton.text('Tampilkan Deskripsi');

        // Toggle form ulasan
        reviewForm.toggle();
        showReviewFormButton.text(reviewForm.is(':visible') ? 'Sembunyikan Form Ulasan' : 'Tampilkan Form Ulasan');
    });

    // Event listener untuk form ulasan
    $('#ulasanForm').submit(function(event) {
        event.preventDefault(); // Mencegah form dikirim secara normal

        var formData = $(this).serialize(); // Mengambil data dari form

        $.ajax({
            url: 'ulasanbuku.php', // URL untuk menyimpan ulasan ke database
            type: 'POST',
            data: formData,
            success: function(response) {
                // Jika sukses, tampilkan pesan sukses
                alert('Ulasan berhasil dikirim!');
                reviewForm.hide(); // Sembunyikan form ulasan setelah berhasil kirim
                showReviewFormButton.text('Tampilkan Form Ulasan'); // Perbarui teks tombol
            },
            error: function(xhr, status, error) {
                alert('Terjadi kesalahan, coba lagi nanti!');
            }
        });
    });
    $(document).ready(function() {
    // Event listener untuk tombol "Tambah ke Koleksi Pribadi"
    $('#addToCollectionButton').click(function() {
        var BukuID = <?php echo $BukuID['BukuID']; ?>;

        $.ajax({
            url: 'koleksipribadi.php', // PHP untuk menambahkan ke koleksi pribadi
            type: 'POST',
            data: { BukuID: BukuID },
            success: function(response) {
                alert(response); // Tampilkan pesan berhasil atau gagal
            },
            error: function(xhr, status, error) {
                alert('Terjadi kesalahan, coba lagi nanti!');
            }
        });
    });
});
$(document).ready(function() {
    // Membuka profil di halaman baru ketika tautan diklik
    $('#openProfileLink').click(function(event) {
        event.preventDefault(); // Mencegah perilaku default tautan

        // Konfirmasi sebelum membuka profil
        if (confirm('Apakah Anda ingin melihat profil Anda?')) {
            window.location.href = 'profiluser.php'; // Mengalihkan ke halaman profil
        }
    });
});

});
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
