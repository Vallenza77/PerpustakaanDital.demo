<?php
session_start();
include('koneksi.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deleteKoleksiID'])) {
    $KoleksID = $_POST['deleteKoleksiID'];

    // 1️⃣ Hapus buku dari koleksi pribadi berdasarkan KoleksID
    $query = "DELETE FROM koleksipribadi WHERE KoleksID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $KoleksID);

    if ($stmt->execute()) {
        // 2️⃣ Reset ulang ID agar tetap berurutan
        $conn->query("SET @num := 0");
        $conn->query("UPDATE koleksipribadi SET KoleksID = @num := @num + 1 ORDER BY KoleksID");
        $conn->query("ALTER TABLE koleksipribadi AUTO_INCREMENT = 1");

        echo "Buku berhasil dihapus dari koleksi.";
    } else {
        echo "Gagal menghapus buku.";
    }

    $stmt->close();
    $conn->close();
} else {
    echo "Permintaan tidak valid.";
}
?>
