<?php
session_start(); // Start the session to access session variables

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if UserID is set in session
    if (!isset($_SESSION['UserID'])) {
        echo "User is not logged in.";
        exit();
    }

    // Get the form data
    $UserID = $_SESSION['UserID'];  // The logged-in user ID from session
    $BukuID = $_POST['BukuID'];     // The ID of the book being reviewed
    $Ulasan = $_POST['Ulasan'];     // The user's review text
    $Rating = $_POST['Rating'];     // The rating provided by the user

    // Check if the review and rating are provided
    if (empty($Ulasan) || empty($Rating)) {
        echo "Please provide both a review and a rating.";
        exit();
    }

    // Include the database connection file
    include('koneksi.php');

    // Insert review into the database
    $query = "INSERT INTO ulasanbuku (UserID, BukuID, Ulasan, Rating) 
              VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iisi", $UserID, $BukuID, $Ulasan, $Rating); // Correctly bind the parameters

    // Execute the query
    if ($stmt->execute()) {
        // If successful, redirect to the books page or a new page to show reviews
        echo "<script>alert('Ulasan berhasil ditambahkan'); window.location.href='peminjamanuser.php';</script>";
    } else {
        // If there is an error, show the error message
        echo "Terjadi kesalahan: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
} else {
    // If the request is not a POST, redirect back to the books page
    header("Location: ulasanuser.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form dan Ulasan Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .star {
            font-size: 18px;
            color: lightgray;
            cursor: pointer;
        }

        .star.filled {
            color: gold;
        }

        .ulasan {
            border-bottom: 1px solid #ddd;
            margin-bottom: 15px;
            padding-bottom: 15px;
        }

        .alert {
            margin-top: 15px;
        }

        .form-container {
            background-color: #f8f9fa;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .form-title {
            font-size: 24px;
            font-weight: bold;
            color: #007bff;
            margin-bottom: 30px;
        }

        .btn-submit {
            width: 100%;
        }
    </style>
</head>
<body>
<div class="container my-5">
    <div class="form-container">
        <h1 class="form-title">Tambah Ulasan Buku</h1>
        <!-- Form untuk menambahkan ulasan -->
        <form method="post" action="ulasanuser.php">

            <div class="mb-3">
                <label for="bukuID" class="form-label">Judul Buku:</label>
                <select id="bukuID" name="bukuID" class="form-select" required>
                    <option value="">Pilih Buku</option>
                    <?php
                    // Menampilkan buku yang tersedia untuk dipilih
                    if ($resultBuku && $resultBuku->num_rows > 0) {
                        while ($row = $resultBuku->fetch_assoc()) {
                            echo "<option value='" . $row['BukuID'] . "'>" . htmlspecialchars($row['Judul']) . "</option>";
                        }
                    } else {
                        echo "<option value=''>Tidak ada buku tersedia</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="ulasan" class="form-label">Ulasan:</label>
                <textarea id="ulasan" name="ulasan" rows="4" class="form-control" required></textarea>
            </div>

            <div class="mb-3">
                <label for="rating" class="form-label">Rating (1-5):</label>
                <div class="star-rating">
                    <span class="star" data-value="1"><i class="fas fa-star"></i></span>
                    <span class="star" data-value="2"><i class="fas fa-star"></i></span>
                    <span class="star" data-value="3"><i class="fas fa-star"></i></span>
                    <span class="star" data-value="4"><i class="fas fa-star"></i></span>
                    <span class="star" data-value="5"><i class="fas fa-star"></i></span>
                    <input type="hidden" name="rating" id="rating" value="1" required>
                </div>
            </div>

            <button type="submit" class="btn btn-primary btn-submit">Kirim Ulasan</button>
        </form>
    </div>
</div>

<script>
    // Set rating based on star selection
    const stars = document.querySelectorAll('.star');
    stars.forEach(star => {
        star.addEventListener('click', function () {
            const value = this.getAttribute('data-value');
            document.getElementById('rating').value = value;

            // Update star colors
            stars.forEach(s => s.classList.remove('filled'));
            for (let i = 0; i < value; i++) {
                stars[i].classList.add('filled');
            }
        });
    });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
