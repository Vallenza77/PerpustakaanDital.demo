<?php
// Konfigurasi database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_perpustakaan"; // Ganti dengan nama database Anda

// Membuat koneksi
$conn = new mysqli($servername, $username, $password, $dbname);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Fungsi untuk menambahkan relasi kategori dan buku
function tambahRelasi($bukuID, $kategoriID) {
    global $conn;
    $sql = "INSERT INTO kategoribuku_relasi (BukuID, KategoriID) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $bukuID, $kategoriID);

    if ($stmt->execute()) {
        echo "Relasi berhasil ditambahkan.";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

// Fungsi untuk menampilkan buku berdasarkan kategori yang dipilih
function tampilkanBukuBerdasarkanKategori($kategoriID = null) {
    global $conn;
    $sql = "SELECT b.BukuID, b.JudulBuku, k.NamaKategori
            FROM buku b
            LEFT JOIN kategoribuku_relasi r ON b.BukuID = r.BukuID
            LEFT JOIN kategoribuku k ON r.KategoriID = k.KategoriID";
    
    // Filter jika kategori dipilih
    if ($kategoriID) {
        $sql .= " WHERE r.KategoriID = ?";
    }

    $stmt = $conn->prepare($sql);

    // Jika kategori dipilih, bind parameter
    if ($kategoriID) {
        $stmt->bind_param("i", $kategoriID);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<table border='1' cellpadding='5' cellspacing='0' style='margin-top: 20px; width: 100%;'>
                <tr>
                    <th>ID Buku</th>
                    <th>Judul Buku</th>
                    <th>Kategori</th>
                </tr>";
        
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>" . $row["BukuID"] . "</td>
                    <td>" . $row["JudulBuku"] . "</td>
                    <td>" . ($row["NamaKategori"] ? $row["NamaKategori"] : 'Tidak Ada Kategori') . "</td>
                  </tr>";
        }

        echo "</table>";
    } else {
        echo "Tidak ada buku yang ditemukan untuk kategori ini.";
    }

    $stmt->close();
}

// Ambil daftar buku
function getBukuList() {
    global $conn;
    $sql = "SELECT BukuID, JudulBuku FROM buku";
    return $conn->query($sql);
}

// Ambil daftar kategori
function getKategoriList() {
    global $conn;
    $sql = "SELECT KategoriID, NamaKategori FROM kategoribuku";
    return $conn->query($sql);
}

// Jika form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_relasi'])) {
    $bukuID = intval($_POST['BukuID']);
    $kategoriID = intval($_POST['KategoriID']);
    tambahRelasi($bukuID, $kategoriID);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Relasi Kategori dan Buku</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .form-container {
            margin-top: 20px;
        }
        .form-container form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .form-container label {
            font-weight: bold;
        }
        .form-container select {
            padding: 10px;
            width: 100%;
            box-sizing: border-box;
        }
        .form-container button {
            padding: 10px 20px;
            background-color: #3498db;
            color: white;
            border: none;
            cursor: pointer;
        }
        .form-container button:hover {
            background-color: #2980b9;
        }
        table {
            margin-top: 20px;
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>
    <h1>Manajemen Relasi Kategori dan Buku</h1>

    <div class="form-container">
        <h2>Tambah Relasi</h2>
        <form method="POST" action="">
            <label for="BukuID">Pilih Buku:</label>
            <select id="BukuID" name="BukuID" required>
                <option value="">-- Pilih Buku --</option>
                <?php
                $bukuList = getBukuList();
                while ($row = $bukuList->fetch_assoc()): ?>
                    <option value="<?= htmlspecialchars($row['BukuID']) ?>">
                        <?= htmlspecialchars($row['JudulBuku']) ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <label for="KategoriID">Pilih Kategori:</label>
            <select id="KategoriID" name="KategoriID" required>
                <option value="">-- Pilih Kategori --</option>
                <?php
                $kategoriList = getKategoriList();
                while ($row = $kategoriList->fetch_assoc()): ?>
                    <option value="<?= htmlspecialchars($row['KategoriID']) ?>">
                        <?= htmlspecialchars($row['NamaKategori']) ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <button type="submit" name="add_relasi">Tambahkan Relasi</button>
        </form>
    </div>

    <h2>Filter Buku Berdasarkan Kategori</h2>
    <form method="GET" action="">
        <label for="filterKategori">Pilih Kategori untuk Filter Buku:</label>
        <select id="filterKategori" name="KategoriID" required>
            <option value="">-- Pilih Kategori --</option>
            <?php
            $kategoriList = getKategoriList();
            while ($row = $kategoriList->fetch_assoc()): ?>
                <option value="<?= htmlspecialchars($row['KategoriID']) ?>">
                    <?= htmlspecialchars($row['NamaKategori']) ?>
                </option>
            <?php endwhile; ?>
        </select>

        <button type="submit">Tampilkan Buku</button>
    </form>

    <h2>Daftar Buku Berdasarkan Kategori</h2>
    <?php
    // Cek apakah ada kategori yang dipilih
    if (isset($_GET['KategoriID']) && !empty($_GET['KategoriID'])) {
        $kategoriID = intval($_GET['KategoriID']);
        tampilkanBukuBerdasarkanKategori($kategoriID);
    } else {
        tampilkanBukuBerdasarkanKategori(); // Tampilkan semua buku jika kategori tidak dipilih
    }
    ?>
</body>
</html>

<?php
$conn->close();
?>
