<?php
// Koneksi ke database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'db_perpustakaan');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil ID kategori dari URL
if (isset($_GET['id'])) {
    $kategori_id = intval($_GET['id']);

    // Ambil data kategori berdasarkan ID
    $query = "SELECT * FROM kategoribuku WHERE KategoriID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $kategori_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nama_kategori = $row['NamaKategori'];
    } else {
        echo "Kategori tidak ditemukan.";
        exit;
    }
}

// Update kategori
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_category'])) {
    $nama_kategori = $conn->real_escape_string($_POST['NamaKategori']);

    $update_sql = "UPDATE kategoribuku SET NamaKategori = ? WHERE KategoriID = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param('si', $nama_kategori, $kategori_id);

    if ($stmt->execute()) {
        header('Location: kategoribuku.php');
        exit;
    } else {
        $message = "Gagal memperbarui kategori: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Kategori Buku</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .form-container form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        .form-container label {
            font-weight: bold;
        }
        .form-container input[type="text"] {
            padding: 10px;
            width: 100%;
            box-sizing: border-box;
        }
        .form-container button {
            padding: 10px 20px;
            background-color: #3498db;
            color: white;
            border: none;
            cursor: pointer;
        }
        .form-container button:hover {
            background-color: #2980b9;
        }
    </style>
</head>
<body>
    <h1>Edit Kategori Buku</h1>

    <?php if (isset($message)): ?>
        <div class="message">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <div class="form-container">
        <form method="POST" action="">
            <label for="NamaKategori">Nama Kategori:</label>
            <input type="text" id="NamaKategori" name="NamaKategori" value="<?= htmlspecialchars($nama_kategori) ?>" required>

            <button type="submit" name="update_category">Perbarui</button>
        </form>
    </div>
</body>
</html>

<?php
$conn->close();
?>
