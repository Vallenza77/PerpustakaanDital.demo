<?php
// Include the database connection file
include('koneksi.php');

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the form data
    $UserID = $_POST['UserID'];  // The logged-in user ID
    $BukuID = $_POST['BukuID'];  // The ID of the book being reviewed
    $Ulasan = $_POST['Ulasan'];  // The user's review text
    $Rating = $_POST['Rating'];  // The rating provided by the user

    // Check if the review and rating are provided
    if (empty($Ulasan) || empty($Rating)) {
        echo "Please provide both a review and a rating.";
        exit();
    }

    // Insert review into the database
    $query = "INSERT INTO ulasanbuku (UserID, BukuID, Ulasan, Rating) 
              VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("iisi", $UserID, $BukuID, $Ulasan, $Rating); // Correctly bind the parameters

    // Execute the query
    if ($stmt->execute()) {
        // If successful, redirect to the books page
        echo "<script>alert('Ulasan berhasil ditambahkan'); window.location.href='peminjamanuser.php';</script>";
    } else {
        // If there is an error, show the error message
        echo "Terjadi kesalahan: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
} else {
    // If the request is not a POST, redirect back to the books page
    header("Location: peminjamanuser.php");
    exit();
}
?>
