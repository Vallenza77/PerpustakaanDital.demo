<?php
include('koneksi.php');

if (isset($_GET['UlasanID'])) {
    $UlasanID = $_GET['UlasanID'];

    // Query untuk menghapus ulasan berdasarkan UlasanID
    $queryHapus = "DELETE FROM ulasanbuku WHERE UlasanID = ?";
    $stmt = $conn->prepare($queryHapus);
    $stmt->bind_param("i", $UlasanID);

    if ($stmt->execute()) {
        // 🆕 Reset ulang ID agar tetap berurutan
        $conn->query("SET @num := 0");
        $conn->query("UPDATE ulasanbuku SET UlasanID = @num := @num + 1 ORDER BY UlasanID");
        $conn->query("ALTER TABLE ulasanbuku AUTO_INCREMENT = 1");

        // Redirect dengan pesan sukses
        header("Location: dataulasan.php?message=Ulasan berhasil dihapus");
        exit();
    } else {
        echo "Gagal menghapus ulasan: " . $stmt->error;
    }

    $stmt->close();
} else {
    header("Location: ulasanbuku.php");
    exit();
}

$conn->close();
?>
