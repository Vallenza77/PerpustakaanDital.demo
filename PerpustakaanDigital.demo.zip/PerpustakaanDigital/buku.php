<?php
// Include the database connection file
include('koneksi.php');

// Function to handle file upload
function uploadImage($foto) {
    $targetDir = "uploads/";
    if (!is_dir('uploads')) {
        mkdir('uploads', 0777, true);
    }

    // Generate a unique filename
    $targetFile = $targetDir . uniqid() . basename($foto['name']);
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Check if file is an image
    $check = getimagesize($foto['tmp_name']);
    if ($check === false) {
        echo "File is not an image.";
        return false;
    }

    // Check file size (max 5MB)
    if ($foto['size'] > 5000000) {
        echo "Sorry, your file is too large.";
        return false;
    }

    // Allow certain file formats
    if (!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        return false;
    }

    // Upload the file
    if (move_uploaded_file($foto['tmp_name'], $targetFile)) {
        return $targetFile;
    } else {
        echo "Sorry, there was an error uploading your file.";
        return false;
    }
}

// Ambil daftar kategori dari database
$queryKategori = "SELECT DISTINCT NamaKategori FROM buku ORDER BY NamaKategori ASC";
$resultKategori = $conn->query($queryKategori);

// Cek apakah query berjalan dengan benar
if (!$resultKategori) {
    die("Query error: " . $conn->error);
}

$categories = [];
while ($row = $resultKategori->fetch_assoc()) {
    $categories[] = $row['NamaKategori'];
}

$kategori = isset($_GET['kategori']) ? $_GET['kategori'] : 'Semua';
$searchQuery = isset($_GET['search']) ? $_GET['search'] : '';

// Buat query untuk mengambil buku berdasarkan kategori dan search
$query = "SELECT * FROM buku WHERE 1=1";

// If a category is selected, filter by category
if ($kategori !== 'Semua') {
    $query .= " AND NamaKategori = ?";
}

// If a search term is provided, filter by book title
if (!empty($searchQuery)) {
    $query .= " AND Judul LIKE ?";
}

$stmt = $conn->prepare($query);

// Bind parameters for category and search (if present)
if ($kategori !== 'Semua' && !empty($searchQuery)) {
    $stmt->bind_param("ss", $kategori, "%$searchQuery%");
} elseif ($kategori !== 'Semua') {
    $stmt->bind_param("s", $kategori);
} elseif (!empty($searchQuery)) {
    $stmt->bind_param("s", "%$searchQuery%");
}

$stmt->execute();
$result = $stmt->get_result();

// Fetch BukuIDs from the database
$BukuIDs = [];
while ($row = $result->fetch_assoc()) {
    $BukuIDs[] = $row;
}

$stmt->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Modal Styling */
        .modal-content {
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }

        .modal-header {
            background-color: #007bff;
            color: #fff;
            padding: 15px 20px;
            border-bottom: none;
        }

        .modal-body {
            padding: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            align-items: flex-start;
        }

        .modal-body img {
            width: 100%;
            max-width: 300px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .modal-body .BukuID-details {
            flex: 1;
            padding: 0 20px;
        }

        .modal-body .form-section {
            flex: 1;
        }

        .modal-footer {
            justify-content: space-between;
            padding: 15px 20px;
            background-color: #f9f9f9;
        }

        /* Button Styling */
        .btn-success {
            background-color: #28a745;
            border-color: #28a745;
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: bold;
        }

        .btn-success:hover {
            background-color: #218838;
            border-color: #1e7e34;
        }

        /* Rating Section */
        .rating {
            display: flex;
            flex-direction: row-reverse;
            justify-content: flex-start;
            gap: 5px;
        }

        .rating input[type="radio"] {
            display: none;
        }

        .rating label {
            font-size: 30px;
            color: #ddd;
            cursor: pointer;
        }

        .rating input[type="radio"]:checked ~ label {
            color: #ffc107;
        }

        .rating label:hover,
        .rating label:hover ~ label {
            color: #ffc107;
        }
    </style>
</head>
<body>
<div class="container my-5">
    <h1 class="text-center mb-4">Daftar Buku</h1>

    <form method="GET" class="mb-4">
        <div class="row align-items-center">
            <div class="col-md-4">
                <label for="kategoriSelect" class="form-label">Pilih Kategori:</label>
                <select id="kategoriSelect" name="kategori" class="form-select">
                    <option value="Semua">Semua Kategori</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= htmlspecialchars($category); ?>" <?= $kategori == $category ? 'selected' : ''; ?>>
                            <?= htmlspecialchars($category); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-4">
                <label for="tahunTerbitSelect" class="form-label">Pilih Tahun Terbit:</label>
                <select id="tahunTerbitSelect" name="tahunTerbit" class="form-select">
                    <option value="Semua">Semua Tahun</option>
                    <!-- Data will be populated by AJAX -->
                </select>
            </div>

            <div class="col-md-4">
                <label for="searchInput" class="form-label">Cari Judul Buku:</label>
                <input type="text" id="searchInput" name="search" class="form-control" placeholder="Cari judul buku..." value="<?= htmlspecialchars($searchQuery); ?>">
            </div>
        </div>
    </form>

    <div class="row" id="BukuIDList">
        <?php foreach ($BukuIDs as $index => $BukuID): ?>
            <div class="col-md-4">
                <div class="card BukuID-card">
                    <div class="card-body">
                        <img src="<?= $BukuID['foto']; ?>" alt="<?= $BukuID['Judul']; ?>" class="BukuID-foto">
                        <h5 class="card-title"><?= $BukuID['Judul']; ?></h5>
                        <p class="card-text"><strong>Penulis:</strong> <?= $BukuID['Penulis']; ?></p>
                        <p class="card-text"><strong>Penerbit:</strong> <?= $BukuID['Penerbit']; ?></p>
                        <p class="card-text"><strong>Tahun Terbit:</strong> <?= $BukuID['TahunTerbit']; ?></p>
                        <p class="card-text"><strong>Kategori:</strong> <?= $BukuID['NamaKategori']; ?></p>
                        <a href="peminjamanuser.php?BukuID=<?= $BukuID['BukuID']; ?>" class="btn btn-info w-100">Lihat Buku</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
        $(document).ready(function() {
            $('#kategoriSelect').change(function() {
                var kategori = $(this).val(); // Ambil nilai kategori yang dipilih
                
                $.ajax({
                    url: 'filterbuku.php',
                    type: 'POST',
                    data: { kategori: kategori },
                    success: function(response) {
                        $('#BukuIDList').html(response); // Masukkan data ke dalam div daftar buku
                    },
                    error: function() {
                        alert("Terjadi kesalahan dalam memuat data buku.");
                    }
                });

                // Ambil Tanggal Terbit dari database berdasarkan kategori
                $.ajax({
                    url: 'get_tanggal_terbit.php',
                    type: 'POST',
                    data: { kategori: kategori },
                    success: function(response) {
                        $('#tanggalTerbitList').html(response); // Masukkan data tanggal terbit ke div
                    }
                });
            });
            $(document).ready(function() {
    // Membuka profil di halaman baru ketika tautan diklik
    $('#openProfileLink').click(function(event) {
        event.preventDefault(); // Mencegah perilaku default tautan

        // Konfirmasi sebelum membuka profil
        if (confirm('Apakah Anda ingin melihat profil Anda?')) {
            window.location.href = 'profiluser.php'; // Mengalihkan ke halaman profil
        }
    });
});

        });
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
