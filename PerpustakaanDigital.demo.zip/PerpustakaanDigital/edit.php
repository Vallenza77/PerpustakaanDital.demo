<?php
session_start();

// Include the database connection file
include('koneksi.php');

// Get the book ID from the URL
$BukuID = isset($_GET['id']) ? $_GET['id'] : '';

// Fetch book details from the database
if ($BukuID) {
    $query = "SELECT * FROM buku WHERE BukuID = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $BukuID);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $book = $result->fetch_assoc();
    } else {
        echo "Buku tidak ditemukan.";
        exit;
    }
} else {
    echo "ID Buku tidak diberikan.";
    exit;
}

// Fetch categories from the database
$queryCategories = "SELECT * FROM buku";
$resultCategories = $conn->query($queryCategories);

// Check if the query was successful
if ($resultCategories === false) {
    echo "Error: " . $conn->error;
    exit;
}

$categories = $resultCategories->fetch_all(MYSQLI_ASSOC);

// Update book details if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $Judul = isset($_POST['Judul']) ? $_POST['Judul'] : '';
    $Penulis = isset($_POST['Penulis']) ? $_POST['Penulis'] : '';
    $Penerbit = isset($_POST['Penerbit']) ? $_POST['Penerbit'] : '';
    $TahunTerbit = isset($_POST['TahunTerbit']) ? $_POST['TahunTerbit'] : '';
    $NamaKategori = isset($_POST['NamaKategori']) ? $_POST['NamaKategori'] : '';
    $Deskripsi = isset($_POST['Deskripsi']) ? $_POST['Deskripsi'] : '';
    
    // Handle multiple file upload
    $imagePath = isset($_FILES['foto']) ? uploadImage($_FILES['foto']) : $book['foto'];

    // If the image upload is successful, update the book in the database
    if ($imagePath !== false) {
        $query = "UPDATE buku SET Judul = ?, Penulis = ?, Penerbit = ?, TahunTerbit = ?, NamaKategori = ?, Deskripsi = ?, foto = ? WHERE BukuID = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssssssi", $Judul, $Penulis, $Penerbit, $TahunTerbit, $NamaKategori, $Deskripsi, $imagePath, $BukuID);

        if ($stmt->execute()) {
            echo "<script>alert('Buku berhasil diperbarui'); window.location.href='bukuadmin.php';</script>";
        } else {
            echo "Terjadi kesalahan: " . $stmt->error;
        }

        $stmt->close();
    }
}

// Function to handle file upload
function uploadImage($foto) {
    $targetDir = "uploads/"; // Directory to save the uploaded foto
    if (!is_dir('uploads')) {
        mkdir('uploads', 0777, true); // Membuat folder dengan izin 777 jika belum ada
    }

    // Check if the file is uploaded
    if ($foto['error'] != UPLOAD_ERR_OK) {
        echo "There was an error uploading the file.";
        return false;
    }

    // Generate a unique filename by appending a timestamp
    $targetFile = $targetDir . uniqid() . basename($foto['name']); // Create a unique file name
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION)); // Get file extension

    // Check if file is an image
    $check = getimagesize($foto['tmp_name']); // Check the temporary file
    if ($check === false) {
        echo "File is not an image.";
        return false;
    }

    // Check file size (max 5MB)
    if ($foto['size'] > 5000000) {
        echo "Sorry, your file is too large.";
        return false;
    }

    // Allow certain file formats
    if (!in_array($imageFileType, ['jpg', 'jpeg', 'png', 'gif'])) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        return false;
    }

    // Try to upload the file
    if (move_uploaded_file($foto['tmp_name'], $targetFile)) {
        return $targetFile; // Return the file path after uploading
    } else {
        echo "Sorry, there was an error uploading your file.";
        return false;
    }
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: Arial, sans-serif;
        }
        .container {
            max-width: 600px;
            margin-top: 50px;
            background: #fff;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 24px;
            color: #343a40;
        }
        .form-label {
            font-weight: bold;
        }
        .btn {
            width: 100%;
            font-size: 16px;
        }
        .book-foto {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit Buku</h1>
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="Judul" class="form-label">Judul Buku</label>
                <input type="text" class="form-control" id="Judul" name="Judul" value="<?php echo $book['Judul']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="Penulis" class="form-label">Penulis</label>
                <input type="text" class="form-control" id="Penulis" name="Penulis" value="<?php echo $book['Penulis']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="Penerbit" class="form-label">Penerbit</label>
                <input type="text" class="form-control" id="Penerbit" name="Penerbit" value="<?php echo $book['Penerbit']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="TahunTerbit" class="form-label">Tahun Terbit</label>
                <input type="date" class="form-control" id="TahunTerbit" name="TahunTerbit" value="<?php echo $book['TahunTerbit']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="NamaKategori" class="form-label">Kategori Buku</label>
                <select id="NamaKategori" name="NamaKategori" class="form-control" required>
                    <option value="">Pilih Kategori</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['NamaKategori']; ?>" <?php echo $book['NamaKategori'] == $category['NamaKategori'] ? 'selected' : ''; ?>>
                            <?php echo $category['NamaKategori']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label for="Deskripsi" class="form-label">Deskripsi</label>
                <textarea id="Deskripsi" name="Deskripsi" class="form-control" rows="3" required><?php echo $book['Deskripsi']; ?></textarea>
            </div>

            <div class="mb-3">
                <label for="foto" class="form-label">Upload Gambar Buku</label>
                <input type="file" class="form-control" id="foto" name="foto">
            </div>

            <div class="mb-3">
                <label class="form-label">Gambar Saat Ini</label>
                <img src="<?php echo $book['foto']; ?>" class="book-foto mt-2" alt="Gambar Buku">
            </div>

            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
