<?php
// Koneksi ke database
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'db_perpustakaan');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Tambah Kategori Buku
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_category'])) {
    $nama_kategori = $conn->real_escape_string($_POST['NamaKategori']);

    $sql = "INSERT INTO kategoribuku (NamaKategori) VALUES (?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $nama_kategori);

    if ($stmt->execute()) {
        $message = "Kategori berhasil ditambahkan.";
    } else {
        $message = "Gagal menambahkan kategori: " . $conn->error;
    }
}

// Tampilkan kategori buku
$query = "SELECT KategoriID, NamaKategori FROM kategoribuku ORDER BY KategoriID ASC";
$result = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Kategori Buku</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
        }

        /* Styling untuk sidebar */
        .sidebar {
            width: 250px;
            background-color: #2c3e50; /* Warna biru tua */
            color: white;
            height: 100vh;
            padding: 20px;
            box-sizing: border-box;
            position: fixed;
        }

        .sidebar h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            margin: 15px 0;
        }

        .sidebar ul li a {
            text-decoration: none;
            color: white;
            font-size: 18px;
            display: block;
            padding: 10px;
            border-radius: 5px;
        }

        .sidebar ul li a:hover {
            background-color: #34495e;
        }

        /* Konten utama */
        .content {
            margin-left: 250px; /* Menyesuaikan lebar sidebar */
            padding: 20px;
            width: calc(100% - 250px);
            box-sizing: border-box;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #3498db;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .form-container {
            margin-top: 20px;
        }

        .form-container form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        .form-container label {
            font-weight: bold;
        }

        .form-container input[type="text"] {
            padding: 10px;
            width: 100%;
            box-sizing: border-box;
        }

        .form-container button {
            padding: 10px 20px;
            background-color: #3498db;
            color: white;
            border: none;
            cursor: pointer;
        }

        .form-container button:hover {
            background-color: #2980b9;
        }

        .message {
            margin-top: 20px;
            color: green;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h2>Menu</h2>
        <ul>
            <li><a href="dasboardadmin.php">Dashboard</a></li>
            <li><a href="bukuadmin.php">Manajemen Buku</a></li>
            <li><a href="kategoribukurelasi.php">Manajemen Kategori Buku</a></li>
            <li><a href="pengembalian.php">Pengembalian</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>

    <!-- Konten utama -->
    <div class="content">
        <h1>Manajemen Kategori Buku</h1>

        <?php if (isset($message)): ?>
            <div class="message">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <!-- Form untuk menambah kategori buku -->
        <div class="form-container">
            <h2>Tambah Kategori Buku</h2>
            <form method="POST" action="">
                <label for="NamaKategori">Nama Kategori:</label>
                <input type="text" id="NamaKategori" name="NamaKategori" required>

                <button type="submit" name="add_category">Tambah</button>
            </form>
        </div>

        <!-- Tabel untuk menampilkan kategori buku -->
        <h2>Daftar Kategori Buku</h2>
        <table>
            <thead>
                <tr>
                    <th>Kategori ID</th>
                    <th>Nama Kategori</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr id="kategori-<?= $row['KategoriID'] ?>">
                            <td><?= htmlspecialchars($row['KategoriID']) ?></td>
                            <td><?= htmlspecialchars($row['NamaKategori']) ?></td>
                            <td>
                                <a href="editkategori.php?id=<?= $row['KategoriID'] ?>">Edit</a> | 
                                <button class="delete-btn" data-id="<?= $row['KategoriID'] ?>">Hapus</button>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="3">Tidak ada kategori buku yang ditemukan.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Include jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
      document.addEventListener("DOMContentLoaded", function () {
    // Seleksi semua tombol hapus
    document.querySelectorAll(".delete-btn").forEach(button => {
        button.addEventListener("click", function () {
            const kategoriID = this.dataset.id; // Ambil ID dari atribut data-id

            if (confirm("Apakah Anda yakin ingin menghapus kategori ini?")) {
                this.disabled = true; // Nonaktifkan tombol agar tidak diklik berkali-kali
                
                // Kirim request ke hapuskategori.php
                fetch("hapuskategori.php", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded",
                    },
                    body: `KategoriID=${kategoriID}`
                })
                .then(response => response.text())
                .then(data => {
                    alert(data); // Tampilkan respon dari server

                    // Jika berhasil dihapus, hapus elemen dari tabel
                    if (data.includes("berhasil")) {
                        document.getElementById("kategori-" + kategoriID).remove();
                    }

                    button.disabled = false; // Aktifkan kembali tombol
                })
                .catch(error => {
                    console.error("Terjadi kesalahan:", error);
                    alert("Gagal menghapus kategori, coba lagi!");
                    button.disabled = false;
                });
            }
        });
    });
});

    </script>
</body>
</html>
