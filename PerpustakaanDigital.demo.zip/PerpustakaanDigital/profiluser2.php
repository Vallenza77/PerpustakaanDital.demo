<?php
session_start(); // Mulai sesi

// Cek apakah pengguna sudah login
if (!isset($_SESSION['UserID'])) {
    // Jika belum login, redirect ke halaman login
    header("Location: loginadmin.php");
    exit();
}

// Koneksi ke database
$conn = new mysqli("localhost", "root", "", "db_perpustakaan");

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil data pengguna dari database
$UserID = $_SESSION['UserID'];
$sql = "SELECT username, email, namalengkap, alamat FROM user WHERE UserID = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $UserID);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "Data pengguna tidak ditemukan.";
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Pengguna</title>
    <style>
        /* Styling untuk halaman profil */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
            color: #333;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #1e88e5;
            margin-bottom: 20px;
        }

        .profile-info {
            list-style: none;
            padding: 0;
        }

        .profile-info li {
            margin: 15px 0;
            font-size: 18px;
        }

        .profile-info span {
            font-weight: bold;
            color: #555;
        }

        .actions {
            text-align: center;
            margin-top: 20px;
        }

        .actions a {
            text-decoration: none;
            color: white;
            background: #1e88e5;
            padding: 10px 20px;
            border-radius: 5px;
            margin: 0 10px;
            display: inline-block;
        }

        .actions a:hover {
            background: #1565c0;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Profil Pengguna</h1>
        <ul class="profile-info">
            <li><span>Username:</span> <?= htmlspecialchars($user['username']); ?></li>
            <li><span>Email:</span> <?= htmlspecialchars($user['email']); ?></li>
            <li><span>Nama Lengkap:</span> <?= htmlspecialchars($user['namalengkap']); ?></li>
            <li><span>Alamat:</span> <?= nl2br(htmlspecialchars($user['alamat'])); ?></li>
        </ul>
        <div class="actions">
            <a href="editprofiluser.php">Edit Profil</a>
          
        </div>
    </div>
</body>

</html>
