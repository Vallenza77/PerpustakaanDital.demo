<?php
include('koneksi.php');
include('include.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Removed the extra comma at the end
    register($username, $password);

    // Redirect to login page after successful registration
    header('Location: loginadmin.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Library</title>
    <style>
        /* Reset some default browser styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body styling */
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f7fc;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            padding: 20px;
        }

        /* Container for the login form */
        .container {
            background-color: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 100%;
            max-width: 400px;
        }

        /* Heading */
        h2 {
            font-size: 32px;
            color: #333;
            margin-bottom: 20px;
            font-weight: bold;
        }

        /* Input fields */
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 12px;
            border: 2px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            margin-top: 10px;
            margin-bottom: 20px;
            outline: none;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        /* Focus effect on input fields */
        input[type="text"]:focus,
        input[type="password"]:focus {
            border-color: #42a5f5;
            box-shadow: 0 0 8px rgba(66, 165, 245, 0.4);
        }

        /* Button */
        button {
            background-color: #42a5f5;
            color: white;
            font-size: 16px;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }

        /* Hover and active state for button */
        button:hover {
            background-color: #1e88e5;
            transform: translateY(-2px);
        }

        button:active {
            background-color: #0d47a1;
            transform: translateY(2px);
        }

        /* Error message */
        .error {
            color: red;
            font-size: 14px;
            margin-bottom: 20px;
        }

        /* Register link */
        p {
            font-size: 14px;
            color: #555;
        }

        a {
            color: #42a5f5;
            font-weight: bold;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Register</h2>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Register</button>
        </form>
        <p>Already have an account? <a href="loginadmin.php">Login here</a></p>
    </div>
</body>
</html>
