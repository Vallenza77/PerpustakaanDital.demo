<?php

session_start();

// Memeriksa apakah pengguna sudah login
if (!isset($_SESSION['UserID'])) {
    header("Location: loginuser.php");
    exit();
}

// Mendapatkan username dari session
$username = $_SESSION['username'];

// Include the database connection file
include('koneksi.php');

// Check if a book return request is made
if (isset($_GET['return_id'])) {
    $peminjamanID = $_GET['return_id'];

    // Update the status to 'Returned' in the peminjaman table
    $updateQuery = "UPDATE peminjaman SET StatusPeminjaman = 'Kembali' WHERE PeminjamanID = $peminjamanID";
    if ($conn->query($updateQuery)) {
        // Remove the record from the table after return
        $deleteQuery = "DELETE FROM peminjaman WHERE PeminjamanID = $peminjamanID";
        $conn->query($deleteQuery);

      
    } else {
        echo "<script>alert('Terjadi kesalahan saat memperbarui status buku');</script>";
    }
}

// Mendapatkan parameter pencarian
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Query untuk mengambil data peminjaman dengan pencarian
$queryPeminjaman = "SELECT p.PeminjamanID, p.UserID, p.BukuID, p.TanggalPeminjaman, p.TanggalPengembalian, p.StatusPeminjaman, b.Judul 
                    FROM peminjaman p 
                    JOIN buku b ON p.BukuID = b.BukuID 
                    WHERE p.StatusPeminjaman = 'Dipinjam'";

if (!empty($search)) {
    $queryPeminjaman .= " AND b.Judul LIKE '%$search%'";
}

$resultPeminjaman = $conn->query($queryPeminjaman);

$peminjamanRecords = [];
if ($resultPeminjaman) {
    while ($row = $resultPeminjaman->fetch_assoc()) {
        $peminjamanRecords[] = $row;
    }
} else {
    echo "Terjadi kesalahan dalam mengambil data peminjaman: " . $conn->error;
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Peminjaman Buku</title>
    <link rel="icon" href="/favicon.png">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
        }
        .sidebar {
            height: 100%;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #343a40;
            padding-top: 20px;
        }
        .sidebar a {
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            display: block;
        }
        .sidebar a:hover {
            background-color: #575757;
        }
        .content {
            margin-left: 250px;
            padding: 20px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h3 class="text-center text-white">Admin Panel</h3>
        <a href="dasboardadmin.php">Dashboard</a>
        <a href="bukuadmin.php">Manajemen Buku</a>
        <a href="kategoribuku.php">Kategori Buku</a>
        <a href="kembalikanbuku.php">Data Peminjaman Buku</a>
    </div>

    <!-- Main Content -->
    <div class="content">
        <h1>Daftar Peminjaman Buku</h1>

        <!-- Form Pencarian -->
        <form method="GET" action="" class="mb-4">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Cari buku berdasarkan judul" value="<?php echo htmlspecialchars($search); ?>">
                <button class="btn btn-primary" type="submit">Cari</button>
            </div>
        </form>

        <!-- Tabel Data Peminjaman -->
        <table class="table table-striped">
            <thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Buku</th>
                    <th scope="col">Tanggal Pinjam</th>
                    <th scope="col">Tanggal Kembali</th>
                    <th scope="col">Status Peminjaman</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    $counter = 1;
                    foreach ($peminjamanRecords as $record): 
                ?>
                    <tr>
                        <td><?php echo $counter++; ?></td>
                        <td><?php echo htmlspecialchars($record['Judul']); ?></td>
                        <td><?php echo date('d-m-Y', strtotime($record['TanggalPeminjaman'])); ?></td>
                        <td><?php echo date('d-m-Y', strtotime($record['TanggalPengembalian'])); ?></td>
                        <td><?php echo htmlspecialchars($record['StatusPeminjaman']); ?></td>
                        <td>
                            <a href="?return_id=<?php echo $record['PeminjamanID']; ?>" class="btn btn-success btn-sm">Kembalikan Buku</a>
                        </td>
                    </tr>
                <?php endforeach; ?>

                <?php if (empty($peminjamanRecords)): ?>
                    <tr>
                        <td colspan="6" class="text-center">Tidak ada data peminjaman ditemukan</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
