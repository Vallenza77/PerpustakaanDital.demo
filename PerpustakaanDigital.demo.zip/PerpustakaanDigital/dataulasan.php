<?php

session_start();

// Memeriksa apakah pengguna sudah login
if (!isset($_SESSION['UserID'])) {
    header("Location: loginuser.php");
    exit();
}

// Mendapatkan username dari session
$username = $_SESSION['username'];

// Include the database connection file
include('koneksi.php');

// Menangani pencarian
$search = "";
if (isset($_GET['search'])) {
    $search = $_GET['search'];
}

// Query untuk mengambil data ulasan buku dengan pencarian
$queryUlasan = "SELECT u.UlasanID, u.UserID, u.BukuID, u.Ulasan, u.Rating, us.username, b.Judul 
                FROM ulasanbuku u
                JOIN user us ON u.UserID = us.UserID
                JOIN buku b ON u.BukuID = b.BukuID
                WHERE b.Judul LIKE '%$search%'
                ORDER BY u.UlasanID DESC";
$resultUlasan = $conn->query($queryUlasan);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Ulasan Buku</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }

        /* Sidebar styling */
        .sidebar {
            height: 100vh;
            width: 250px;
            position: fixed;
            top: 0;
            left: 0;
            background-color: #343a40;
            padding: 20px;
        }

        .sidebar h3 {
            color: white;
            text-align: center;
            margin-bottom: 20px;
        }

        .sidebar a {
            color: white;
            text-decoration: none;
            display: block;
            padding: 10px 15px;
            border-radius: 5px;
            margin-bottom: 5px;
        }

        .sidebar a:hover {
            background-color: #495057;
        }

        .main-content {
            margin-left: 270px;
            padding: 20px;
        }

        table th {
            background-color: #f1f1f1;
            font-weight: bold;
        }

        table td {
            background-color: #fff;
        }

        .rating {
            color: #ffc107;
        }
    </style>
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <h3>Perpustakaan</h3>
    <a href="dasboardadmin.php">Dashboard</a>
    <a href="databuku.php">Data Buku</a>
    <a href="ulasanbuku.php">Ulasan Buku</a>
    <a href="logout.php">Logout</a>
</div>

<!-- Main Content -->
<div class="main-content">
    <div class="container">
        <h1 class="mb-4">Data Ulasan Buku</h1>

        <!-- Form pencarian -->
        <form method="get" class="mb-4">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Cari berdasarkan judul buku" value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit" class="btn btn-primary">Cari</button>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>UserID</th>
                        <th>Judul Buku</th>
                        <th>Ulasan</th>
                        <th>Rating</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
               <tbody>
    <?php if ($resultUlasan->num_rows > 0): ?>
        <?php while ($ulasan = $resultUlasan->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($ulasan['UserID']); ?> - <?php echo htmlspecialchars($ulasan['username']); ?></td>
                <td><?php echo htmlspecialchars($ulasan['Judul']); ?></td>
                <td><?php echo htmlspecialchars($ulasan['Ulasan']); ?></td>
                <td class="rating">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <?php if ($i <= $ulasan['Rating']): ?>
                            &#9733; <!-- Star filled -->
                        <?php else: ?>
                            &#9734; <!-- Star outline -->
                        <?php endif; ?>
                    <?php endfor; ?>
                </td>
                <td>
                    <a href="hapusulasan.php?UlasanID=<?php echo $ulasan['UlasanID']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus ulasan ini?');">Hapus</a>
                </td>
            </tr>
        <?php endwhile; ?>
    <?php else: ?>
        <tr>
            <td colspan="5" class="text-center">Tidak ada data ulasan buku</td>
        </tr>
    <?php endif; ?>
</tbody>
            </table>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
