<?php
session_start();

// Memeriksa apakah pengguna sudah login
if (!isset($_SESSION['UserID'])) {
    header("Location: loginuser.php");
    exit();
}

// Mendapatkan username dari session
$username = $_SESSION['username'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perpustakaan Digital</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome for Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">

    <!-- JQuery (required for AJAX) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

   <style>
    .card {
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Bayangan lembut */
        border-radius: 10px; /* Sudut membulat */
        overflow: hidden; /* Menjaga elemen tetap di dalam kartu */
        transition: transform 0.3s ease, box-shadow 0.3s ease; /* Animasi saat hover */
        background-color: #fff; /* Warna latar belakang kartu */
    }
    .card:hover {
        transform: scale(1.03); /* Sedikit membesar saat hover */
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); /* Tambahan bayangan saat hover */
    }
    .card img {
        width: 100%; /* Gambar menyesuaikan lebar container */
        aspect-ratio: 16 / 9; /* Rasio aspek konsisten */
        object-fit: cover; /* Gambar tidak terdistorsi */
        transition: transform 0.3s ease, filter 0.3s ease; /* Animasi untuk efek hover */
    }
    .card img:hover {
        transform: scale(1.1); /* Gambar sedikit membesar saat hover */
        filter: brightness(0.9); /* Sedikit lebih gelap untuk kesan interaktif */
    }
    .card-body {
        padding: 20px; /* Memberikan ruang yang cukup */
    }
    .card-title {
        font-size: 1.25rem;
        font-weight: bold;
        margin-bottom: 10px; /* Jarak antara judul dan teks */
        color: #333; /* Warna teks yang kontras */
    }
    .card-text {
        font-size: 0.95rem;
        color: #666; /* Warna teks yang lembut */
        line-height: 1.5; /* Membuat teks lebih mudah dibaca */
    }
    .btn-primary {
        border-radius: 20px; /* Tombol lebih estetis */
        transition: background-color 0.3s ease, transform 0.3s ease; /* Efek interaktif */
    }
    .btn-primary:hover {
        background-color: #0056b3; /* Perubahan warna saat hover */
        transform: scale(1.05); /* Sedikit membesar saat hover */
    }
</style>


</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="dasboard.php">My Website</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="#">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contact</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="loginuser.php" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user"></i> <?= $username; ?>
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profiluser.php"><i class="fas fa-user-circle"></i> Profile</a></li>
                            <li><a class="dropdown-item" href="settings.php"><i class="fas fa-cogs"></i> Settings</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logoutuser.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <header class="bg-primary text-white text-center py-5">
        <div class="container">
            <h1>Welcome to My Website</h1>
            <p class="lead">A simple and responsive website</p>
        </div>
    </header>

    <main class="container my-5">
        <!-- Search Feature -->
        <div class="row mb-4">
            <div class="col-md-12">
                <form method="GET" action="buku.php" class="d-flex">
                    <input class="form-control me-2" type="search" name="query" placeholder="Cari Nama Buku" aria-label="Search">
                    <button class="btn btn-outline-primary" type="submit">Search</button>
                </form>
            </div>
        </div>

        <div class="row">
            <!-- Tambahkan tombol Beranda dengan ID spesifik -->
            <div class="col-md-4 mb-3">
                <button class="btn btn-primary w-100" id="loadBerandaBtn">Beranda</button>
            </div>
            <div class="col-md-4 mb-3">
                <button class="btn btn-primary w-100" id="loadBukuBtn">Daftar Buku</button>
        </div>
        <div class="col-md-4 mb-3">
                <button class="btn btn-primary w-100" id="loadKoleksiBukuBtn">Koleksi Buku Saya</button>
            </div>

        <!-- Content will load here when the "Daftar Buku" or "Beranda" button is clicked -->
        <div id="content-area">
            
            <!-- Dynamic content from beranda.php will appear here -->
        </div>
    </main>

    <footer class="bg-dark text-white text-center py-3">
        <p>© 2025 My Website. All rights reserved.</p>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Custom JS for AJAX -->
    <script>
        $(document).ready(function() {
            // Memuat Beranda secara otomatis saat halaman pertama kali dimuat
            $('#content-area').load('beranda.php', function(response, status, xhr) {
                if (status == "error") {
                    $('#content-area').html("<div class='alert alert-danger'>Unable to load Beranda: " + xhr.status + " " + xhr.statusText + "</div>");
                }
            });

            // Load Buku page via AJAX ketika tombol "Daftar Buku" diklik
            $('#loadBukuBtn').on('click', function() {
                $('#content-area').load('buku.php', function(response, status, xhr) {
                    if (status == "error") {
                        $('#content-area').html("<div class='alert alert-danger'>Unable to load Buku: " + xhr.status + " " + xhr.statusText + "</div>");
                    }
                });
            });

            // Load Beranda page via AJAX ketika tombol "Beranda" diklik
            $('#loadBerandaBtn').on('click', function() {
                $('#content-area').load('beranda.php', function(response, status, xhr) {
                    if (status == "error") {
                        $('#content-area').html("<div class='alert alert-danger'>Unable to load Beranda: " + xhr.status + " " + xhr.statusText + "</div>");
                    }
                });
            });

              // Load Koleksi Buku page via AJAX ketika tombol "Koleksi Buku" diklik
              $('#loadKoleksiBukuBtn').on('click', function() {
                $('#content-area').load('koleksibuku.php', function(response, status, xhr) {
                    if (status == "error") {
                        $('#content-area').html("<div class='alert alert-danger'>Unable to load Koleksi Buku: " + xhr.status + " " + xhr.statusText + "</div>");
                    }
                });
            });
            $(document).ready(function() {
    // Menampilkan dropdown menu ketika tombol dropdown diklik
    $('#userDropdown').click(function() {
        $('.dropdown-menu').toggleClass('show'); // Toggle kelas 'show' untuk menampilkan/menyembunyikan menu
    });

    // Menangani klik pada link logout dengan konfirmasi
    $('#logoutLink').click(function(event) {
        event.preventDefault(); // Mencegah aksi default untuk logout (perpindahan halaman)

        // Menampilkan konfirmasi sebelum logout
        if (confirm('Apakah Anda yakin ingin logout?')) {
            window.location.href = $(this).attr('href'); // Melanjutkan ke halaman logout jika dikonfirmasi
        }
    });

    // Menyembunyikan dropdown menu ketika pengguna mengklik di luar menu
    $(document).click(function(event) {
        if (!$(event.target).closest('.dropdown-menu').length && !$(event.target).closest('#userDropdown').length) {
            $('.dropdown-menu').removeClass('show');
        }
    });
});

        });
    </script>

</body>

</html>
